<div class="row">
    <div class="col-12">
        <div class="input-group">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $user)): ?>
                <?php if(request('action') == 'add_child'): ?>
                    <div class="list-group-item">
                        <?php echo e(Form::open(['route' => ['family-actions.add-child', $user->id]])); ?>

                        <div class="row">
                            <div class="col-md-8">
                                <?php echo FormField::text('add_child_name', ['label' => __('user.child_name')]); ?>

                            </div>
                            <div class="col-md-4">
                                <?php echo FormField::radios('add_child_gender_id', [1 => __('app.male'), 2 => __('app.female')], ['label' => __('user.child_gender')]); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-8">
                                <?php echo FormField::select('add_child_parent_id', $usersMariageList, ['label' => __('user.add_child_from_existing_couples', ['name' => $user->name]), 'placeholder' => __('app.unknown')]); ?>

                            </div>
                            <div class="col-md-4">
                                <?php echo FormField::text('add_child_birth_order', ['label' => __('user.birth_order'), 'type' => 'number', 'min' => 1]); ?>

                            </div>
                        </div>

                        <?php echo e(Form::submit(__('user.add_child'), ['class' => 'btn btn-success btn-sm'])); ?>

                        <?php echo e(link_to_route('users.show', __('app.cancel'), [$user->id], ['class' => 'btn btn-default btn-sm'])); ?>

                        <?php echo e(Form::close()); ?>

                    </div>
                <?php elseif( $user->childs): ?>
                    <?php $__empty_2 = true; $__currentLoopData = $user->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <div class="col-12 col-md-3">
                            <?php echo e(userPhoto($child, ['class' => 'img-fluid rounded-circle border'])); ?>

                        </div>
                        <div class="col-12 col-md-9 text-center text-lg-left">
                            <div> <span class="text-muted"> <?php echo e($child->gender == 'F' ? __('Daughter') : __('Son**')); ?></span> </div>
                            <div> <strong><?php echo e($child->profileLink()); ?> (<?php echo e($child->gender); ?>)</strong> </div>
                            <?php if($child->yob): ?>
                                <div> <small class="text-muted"><?php echo e(trans('user.dob')); ?> <?php echo e($child->yob); ?></small> </div>
                            <?php endif; ?>
                        </div>
                         

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        
                    <?php endif; ?>
                    <a href="<?php echo e(route('users.show', [$user->id, 'action' => 'add_child'] )); ?>" class="addLink"><i class="fas fa-plus-circle"></i></a>
                        <div class="input-group-append">
                            <span class="mt-3 ml-2"> <small>Add Child</small></span>
                        </div>
                <?php else: ?>
                    <a href="<?php echo e(route('users.show', [$user->id, 'action' => 'add_child'] )); ?>" class="addLink"><i class="fas fa-plus-circle"></i></a>
                    <div class="input-group-append">
                        <span class="mt-3 ml-2"> <small>Add Child</small></span>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                
                    <?php $__empty_2 = true; $__currentLoopData = $user->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <div class="col-12 col-md-3">
                            <?php echo e(userPhoto($child, ['class' => 'img-fluid rounded-circle border'])); ?>

                        </div>
                        <div class="col-12 col-md-9 text-center text-lg-left">
                            <div> <span class="text-muted"> <?php echo e($child->gender == 'F' ? __('Daughter') : __('Son999')); ?></span> </div>
                            <div> <strong><?php echo e($child->profileLink()); ?> (<?php echo e($child->gender); ?>)</strong> </div>
                            <?php if($child->yob): ?>
                                <div> <small class="text-muted"><?php echo e(trans('user.dob')); ?> <?php echo e($child->yob); ?></small> </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <div class="col-12 col-md-9 text-center text-lg-left">
                            <div> <strong><?php echo e(__('Child record not found')); ?></strong> </div>
                        </div>
                    <?php endif; ?>
                
                    
                
            <?php endif; ?>         
        </div>
    </div>
</div>






<?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/partials/childs.blade.php ENDPATH**/ ?>