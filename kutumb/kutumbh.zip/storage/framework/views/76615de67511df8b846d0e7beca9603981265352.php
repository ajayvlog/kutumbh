

<?php
$childsTotal = 0;
$grandChildsTotal = 0;
$ggTotal = 0;
$ggcTotal = 0;
$ggccTotal = 0;

$parentsTotal = 0;
$grandParentsTotal = 0;
$ggPTotal = 0;
$ggPcTotal = 0;
$ggccPTotal = 0;

?>

<div class="container-fluid mt-2 ">
    
    <div class="row">
        <div class="col-12 mt-2">
            <div class="my-custom-scrollbar my-custom-scrollbar-primary">
                <div class="tree">
                    <?php if($parentsCount = $user->parents->count()): ?>
                        <?php $parentsTotal += $parentsCount ?>
                        <?php $__currentLoopData = $user->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($grandsPCount = $parent->parents->count()): ?>
                                <?php $grandParentsTotal += $grandsPCount ?>
                                <?php $__currentLoopData = $parent->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($ggPCount = $grandP->parents->count()): ?>
                                        <?php $ggPTotal += $ggPCount ?>
                                        <?php $__currentLoopData = $grandP->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ggPcCount = $ggP->parents->count()): ?>
                                                <?php $ggPcTotal += $ggPcCount ?>
                                                <?php $__currentLoopData = $ggP->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggcP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($ggccPCount = $ggcP->parents->count()): ?>
                                                        <?php $ggccPTotal += $ggccPCount ?>
                                                        <?php $__currentLoopData = $ggcP->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggccP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <ul>
                                                            <li>
                                                                <div>
                                                                    <span class="male">
                                                                        <a href="<?php echo e(route('users.show',[$ggccP->id])); ?>" title="<?php echo e($ggccP->name.' ('.$ggccP->gender.')'); ?>">
                                                                            <span class="img-gender"><?php echo e(userPhoto($ggccP, ['class' => ''])); ?></span>
                                                                            <span class="name"> <?php echo e($ggccP->name); ?> </span>
                                                                            <span class="gender"><?php echo e($ggccP->gender); ?></span>
                                                                        </a>
                                                                    </span>
                                                                    <?php if($ggccP->gender_id == 1): ?>
                                                                        <?php if($ggccP->wifes->isEmpty() == false): ?>
                                                                            <?php $__currentLoopData = $ggccP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <span class="female">
                                                                                    <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                        <span class="img-gender"><?php echo e(userPhoto($wife, ['class' => ''])); ?></span>
                                                                                        <span class="name"><?php echo e($wife->name); ?></span>
                                                                                        <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                    </a>
                                                                                </span>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <?php if($ggccP->husbands->isEmpty() == false): ?>
                                                                            <?php $__currentLoopData = $ggccP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <span class="female">
                                                                                    <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                        <span class="img-gender"><?php echo e(userPhoto($husband, ['class' => ''])); ?></span>
                                                                                        <span class="name"><?php echo e($husband->name); ?></span>
                                                                                        <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                    </a>
                                                                                </span>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    <ul>
                                                        <li>
                                                            <div>
                                                                <span class="male">
                                                                    <a href="<?php echo e(route('users.show',[$ggcP->id])); ?>" title="<?php echo e('Great Great Grand Father->'. $ggcP->name.' ('.$ggcP->gender.')'); ?>">
                                                                        <span class="img-gender"><?php echo e(userPhoto($ggcP, ['class' => ''])); ?></span>
                                                                        <span class="name"> <?php echo e($ggcP->name); ?> </span>
                                                                        <span class="gender"><?php echo e($ggcP->gender); ?></span>
                                                                    </a>
                                                                </span>
                                                                <?php if($ggcP->gender_id == 1): ?>
                                                                    <?php if($ggcP->wifes->isEmpty() == false): ?>
                                                                        <?php $__currentLoopData = $ggcP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <span class="female">
                                                                                <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="<?php echo e('Great Great Grand Mother->'.  $wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                    <span class="img-gender"><?php echo e(userPhoto($wife, ['class' => ''])); ?></span>
                                                                                    <span class="name"><?php echo e($wife->name); ?></span>
                                                                                    <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                </a>
                                                                            </span>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <?php if($ggcP->husbands->isEmpty() == false): ?>
                                                                        <?php $__currentLoopData = $ggcP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <span class="female">
                                                                                <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="<?php echo e('Great Great Grand Other->'.  $husband->name.' ('.$husband->gender.')'); ?>">
                                                                                    <span class="img-gender"><?php echo e(userPhoto($husband, ['class' => ''])); ?></span>
                                                                                    <span class="name"><?php echo e($husband->name); ?></span>
                                                                                    <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                </a>
                                                                            </span>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                            
                                                <ul>
                                                    <li>
                                                        <div>
                                                            <span class="male">
                                                                <a href="<?php echo e(route('users.show',[$ggP->id])); ?>" title="<?php echo e('Great Grand Father->'. $ggP->name.' ('.$ggP->gender.')'); ?>">
                                                                    <span class="img-gender"><?php echo e(userPhoto($ggP, ['class' => ''])); ?></span>
                                                                    <span class="name"> <?php echo e($ggP->name); ?> </span>
                                                                    <span class="gender"><?php echo e($ggP->gender); ?></span>
                                                                </a>
                                                            </span>
                                                            <?php if($ggP->gender_id == 1): ?>
                                                                <?php if($ggP->wifes->isEmpty() == false): ?>
                                                                    <?php $__currentLoopData = $ggP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <span class="female">
                                                                            <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="<?php echo e('Great Grand Mother->'. $wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, ['class' => ''])); ?></span>
                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                            </a>
                                                                        </span>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($ggP->husbands->isEmpty() == false): ?>
                                                                    <?php $__currentLoopData = $ggP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <span class="female">
                                                                            <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="<?php echo e('Grand other->'. $husband->name.' ('.$husband->gender.')'); ?>">
                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, ['class' => ''])); ?></span>
                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                            </a>
                                                                        </span>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <ul>
                                                <li>
                                                    <div>
                                                        <span class="male">
                                                            <a href="<?php echo e(route('users.show',[$grandP->id])); ?>" title="<?php echo e('Grand Father ->'. $grandP->name.' ('.$grandP->gender.')'); ?>">
                                                                <span class="img-gender"><?php echo e(userPhoto($grandP, ['class' => ''])); ?></span>
                                                                <span class="name"> <?php echo e($grandP->name); ?> </span>
                                                                <span class="gender"><?php echo e($grandP->gender); ?></span>
                                                              
                                                            </a>
                                                        </span>
                                                        <?php if($grandP->gender_id == 1): ?>
                                                            <?php if($grandP->wifes->isEmpty() == false): ?>
                                                                <?php $__currentLoopData = $grandP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <span class="female">
                                                                        <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="<?php echo e('Grand Mother->'. $wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                            <span class="img-gender"><?php echo e(userPhoto($wife, ['class' => ''])); ?></span>
                                                                            <span class="name"><?php echo e($wife->name); ?></span>
                                                                            <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                        </a>
                                                                    </span>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($grandP->husbands->isEmpty() == false): ?>
                                                                <?php $__currentLoopData = $grandP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <span class="female">
                                                                        <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="<?php echo e('Other->'. $husband->name.' ('.$husband->gender.')'); ?>">
                                                                            <span class="img-gender"><?php echo e(userPhoto($husband, ['class' => ''])); ?></span>
                                                                            <span class="name"><?php echo e($husband->name); ?></span>
                                                                            <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                        </a>
                                                                    </span>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <ul>
                                            <li>
                                                <div>
                                                    <span class="male">
                                                        <a href="<?php echo e(route('users.show',[$parent->id])); ?>" title="<?php echo e('Father '. $parent->name.' ('.$parent->gender.')'); ?>">
                                                            <span class="img-gender"><?php echo e(userPhoto($parent, ['class' => ''])); ?></span>
                                                            <span class="name"> <?php echo e($parent->name); ?> </span>
                                                            <span class="gender"><?php echo e($parent->gender); ?></span>
                                                        </a>
                                                    </span> 
                                                    <?php if($parent->gender_id == 1): ?>
                                                        <?php if($parent->wifes->isEmpty() == false): ?>
                                                            <?php $__currentLoopData = $parent->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="female">
                                                                    <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="<?php echo e('Mother '. $wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                        <span class="img-gender"><?php echo e(userPhoto($wife, ['class' => ''])); ?></span>
                                                                        <span class="name"><?php echo e($wife->name); ?></span>
                                                                        <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                    </a>
                                                                </span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php if($parent->husbands->isEmpty() == false): ?>
                                                            <?php $__currentLoopData = $parent->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="female">
                                                                    <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="<?php echo e('Other Parent '. $husband->name.' ('.$husband->gender.')'); ?>">
                                                                        <span class="img-gender"><?php echo e(userPhoto($husband, ['class' => ''])); ?></span>
                                                                        <span class="name"><?php echo e($husband->name); ?></span>
                                                                        <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                    </a>
                                                                </span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>



                                            <!-- For in laws -->

                                            <?php 
                                            $f='';
                                            $m='';
                                            $g='';

                                            if(Auth::check())
                                            {
                                            $g = \App\Helpers\Common::getSpouseParents(Auth::user()->id,Auth::user()->gender_id) ;  
 
                                            if($g) {
                                                $f=\App\Helpers\Common::getUserName($g->father_id);
                                                $m=\App\Helpers\Common::getUserName($g->mother_id);

                                               }
                                            }
                                            ?> 
                                                <div>

                                                 <?php if($f): ?>
                                                    <span class="male">
                                                        <a href="<?php echo e(route('users.show',[$f->id])); ?>" title="<?php echo e('Father in Law '. $parent->name.' ('.$parent->gender.')'); ?>">
                                                            <span class="img-gender"><?php echo e(userPhoto($parent, ['class' => ''])); ?></span>
                                                            <span class="name"> <?php echo e($f->name??''); ?> </span>
                                                            <span class="gender"><?php echo e($f->gender??''); ?></span>
                                                        </a>
                                                    </span> 
                                                 <?php endif; ?> 
                                                  
                                                 <?php if($m): ?>
                                                    <span class="female">
                                                                    <a href="<?php echo e(route('users.show',[$m->id])); ?>" title="<?php echo e('Mother in Law '. $wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                        <span class="img-gender"><?php echo e(userPhoto($wife, ['class' => ''])); ?></span>
                                                                        <span class="name"><?php echo e($m->name); ?></span>
                                                                        <span class="gender"><?php echo e($m->gender); ?></span>
                                                                    </a>
                                                    </span>
                                                 <?php endif; ?>

                                                </div>
                                                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    
                                    <ul>
                                        <li>
                                            <div>
											<?php 
                                            $a=[];
                                            if(Auth::check())
                                            {
                                            if(Auth::user()->parent_id)
                                            {
                                            $a = \App\Helpers\Common::getparents(Auth::user()->parent_id,Auth::user()->birth_order,1) ;   
                                            }
                                            }
                                            ?>
                                            
                                            <?php if(count($a)): ?>
                                            <?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="<?php echo e(($l->gender_id==2)?'female':'male'); ?>">
                                                    <a href="http://192.168.0.27:8000/users/<?php echo e($l->id); ?>" title="<?php echo e(($l->gender_id==2)?'Sister':'Brother'); ?> <?php echo e($l->name); ?> (<?php echo e(($l->gender_id==2)?'F':'M'); ?>)">
                                                        <span class="img-gender"><img src="http://192.168.0.27:8000/images/icon_user_new_<?php echo e(($l->gender_id==2)?'2':'1'); ?>.png"></span>
                                                        <span class="name"> <?php echo e($l->name); ?> </span>
                                                        <span class="gender"><?php echo e(($l->gender_id==2)?'F':'M'); ?></span>
                                                    </a>
                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                            <?php endif; ?>    

												
												
                                                 <span class="male">
                                                    <a href="<?php echo e(route('users.show',[$user->id])); ?>" title="<?php echo e('Self '. $user->name.' ('.$user->gender.')'); ?>">
                                                        <span class="img-gender"><?php echo e(userPhoto($user, [])); ?></span>
                                                        <span class="name"> <?php echo e($user->name); ?> </span>
                                                        <span class="gender"><?php echo e($user->gender); ?></span>
                                                    </a>
                                                </span>
                                                <?php if($user->gender_id == 1): ?>
                                                    <?php if($user->wifes->isEmpty() == false): ?>
                                                        <?php $__currentLoopData = $user->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="female">
                                                                <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="<?php echo e('Wife '. $wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                    <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                    <span class="name"><?php echo e($wife->name); ?></span>
                                                                    <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                </a>
                                                            </span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($user->husbands->isEmpty() == false): ?>
                                                        <?php $__currentLoopData = $user->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="female">
                                                                <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="<?php echo e('Husband '. $husband->name.' ('.$husband->gender.')'); ?>">
                                                                    <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                    <span class="name"><?php echo e($husband->name); ?></span>
                                                                    <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                </a>
                                                            </span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php 
                                                 $a=[];
                                                 if(Auth::check())
                                                 {
                                                 if(Auth::user()->parent_id)
                                                 {
                                                $a = \App\Helpers\Common::getparents(Auth::user()->parent_id,Auth::user()->birth_order,2) ; 
                                                 }
                                                }
                                                ?>
                                            
                                            
                                            <?php if(count($a)): ?>
                                            <?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="<?php echo e(($l->gender_id==2)?'female':'male'); ?>">
                                                    <a href="http://192.168.0.27:8000/users/<?php echo e($l->id); ?>" title="<?php echo e(($l->gender_id==2)?'Sister':'Brother'); ?> <?php echo e($l->name); ?> (<?php echo e(($l->gender_id==2)?'F':'M'); ?>)">
                                                        <span class="img-gender"><img src="http://192.168.0.27:8000/images/icon_user_new_<?php echo e(($l->gender_id==2)?'2':'1'); ?>.png"></span>
                                                        <span class="name"> <?php echo e($l->name); ?> </span>
                                                        <span class="gender"><?php echo e(($l->gender_id==2)?'F':'M'); ?></span>
                                                    </a>
                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                            <?php endif; ?>    
                                            </div>
                                            <?php if($childsCount = $user->childs->count()): ?>
                                                <?php $childsTotal += $childsCount ?>
                                                <ul>
                                                <?php $__currentLoopData = $user->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <div>
                                                             <span class="male">
                                                                <a href="<?php echo e(route('users.show',[$child->id])); ?>" title=" <?php echo e(($child->gender_id==1) ? 'Son' : 'Daughter'); ?> <?php echo e($child->name.' ('.$child->gender.')'); ?>">
                                                                    <span class="img-gender"><?php echo e(userPhoto($child, [])); ?></span>
                                                                    <span class="name"> <?php echo e($child->name); ?> </span>
                                                                    <span class="gender"><?php echo e($child->gender); ?></span>
                                                                </a>
                                                            </span>
                                                            <?php if($child->gender_id == 1): ?>
                                                                <?php if($child->wifes->isEmpty() == false): ?>
                                                                    <?php $__currentLoopData = $child->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <span class="female">
                                                                            <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="<?php echo e('Daughter In Law '. $wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                            </a>
                                                                        </span>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($child->husbands->isEmpty() == false): ?>
                                                                    <?php $__currentLoopData = $child->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <span class="female">
                                                                            <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="<?php echo e('Son In Law '. $husband->name.' ('.$husband->gender.')'); ?>">
                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                            </a>
                                                                        </span>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </div>
                                                        <?php if($grandsCount = $child->childs->count()): ?>
                                                            <?php $grandChildsTotal += $grandsCount ?>
                                                            <ul>
                                                                <?php $__currentLoopData = $child->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li> 
                                                                        <div>
                                                                            <span class="male">
                                                                                <a href="<?php echo e(route('users.show',[$grand->id])); ?>" title="<?php echo e(($grand->gender_id==1) ? 'Grand Son' : 'Grand Daughter'); ?> <?php echo e($grand->name.' ('.$grand->gender.')'); ?>">
                                                                                    <span class="img-gender"><?php echo e(userPhoto($grand, [])); ?></span>
                                                                                    <span class="name"> <?php echo e($grand->name); ?> </span>
                                                                                    <span class="gender"><?php echo e($grand->gender); ?></span>
                                                                                </a>
                                                                            </span>
                                                                            <?php if($grand->gender_id == 1): ?>
                                                                                <?php if($grand->wifes->isEmpty() == false): ?>
                                                                                    <?php $__currentLoopData = $grand->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <span class="female">
                                                                                            <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="Grand Daughters-in-law <?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                            </a>
                                                                                        </span>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php endif; ?>
                                                                            <?php else: ?>
                                                                                <?php if($grand->husbands->isEmpty() == false): ?>
                                                                                    <?php $__currentLoopData = $grand->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <span class="female">
                                                                                            <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="Grand Sons-in-law <?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                            </a>
                                                                                        </span>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php endif; ?>
                                                                            <?php endif; ?>
                                                                        </div> 
                                                                        <?php if($ggCount = $grand->childs->count()): ?>
                                                                            <?php $ggTotal += $ggCount ?>
                                                                            <ul>
                                                                                <?php $__currentLoopData = $grand->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <li>
                                                                                        <div>
                                                                                            <span class="male">
                                                                                                <a href="<?php echo e(route('users.show',[$gg->id])); ?>" title="<?php echo e(($gg->gender_id==1) ? 'Great Grand Son ' : 'Great Grand Daughter '); ?> <?php echo e($gg->name.' ('.$gg->gender.')'); ?>">
                                                                                                    <span class="img-gender"><?php echo e(userPhoto($gg, [])); ?></span>
                                                                                                    <span class="name"> <?php echo e($gg->name); ?> </span>
                                                                                                    <span class="gender"><?php echo e($gg->gender); ?></span>
                                                                                                </a>
                                                                                            </span>
                                                                                            <?php if($gg->gender_id == 1): ?>
                                                                                                <?php if($gg->wifes->isEmpty() == false): ?>
                                                                                                    <?php $__currentLoopData = $gg->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                        <span class="female">
                                                                                                            <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="Great Granddaughters-in-law <?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                                            </a>
                                                                                                        </span>
                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                <?php endif; ?>
                                                                                            <?php else: ?>
                                                                                                <?php if($gg->husbands->isEmpty() == false): ?>
                                                                                                    <?php $__currentLoopData = $gg->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                        <span class="female">
                                                                                                            <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="Great Grandsons-in-law <?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                                            </a>
                                                                                                        </span>
                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                <?php endif; ?>
                                                                                            <?php endif; ?>
                                                                                        </div>
                                                                                        <?php if($ggcCount = $gg->childs->count()): ?>
                                                                                            <?php $ggcTotal += $ggcCount ?>
                                                                                            <ul>
                                                                                                <?php $__currentLoopData = $gg->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <li>
                                                                                                        <div>
                                                                                                            <span class="male">
                                                                                                                <a href="<?php echo e(route('users.show',[$ggc->id])); ?>" title="<?php echo e($ggc->name.' ('.$ggc->gender.')'); ?>">
                                                                                                                    <span class="img-gender"><?php echo e(userPhoto($ggc, [])); ?></span>
                                                                                                                    <span class="name"> <?php echo e($ggc->name); ?> </span>
                                                                                                                    <span class="gender"><?php echo e($ggc->gender); ?></span>
                                                                                                                </a>
                                                                                                            </span>
                                                                                                            <?php if($ggc->gender_id == 1): ?>
                                                                                                                <?php if($ggc->wifes->isEmpty() == false): ?>
                                                                                                                    <?php $__currentLoopData = $ggc->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <span class="female">
                                                                                                                            <a href="<?php echo e(route('users.show',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                                                            </a>
                                                                                                                        </span>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                <?php endif; ?>
                                                                                                            <?php else: ?>
                                                                                                                <?php if($ggc->husbands->isEmpty() == false): ?>
                                                                                                                    <?php $__currentLoopData = $ggc->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <span class="female">
                                                                                                                            <a href="<?php echo e(route('users.show',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                                                            </a>
                                                                                                                        </span>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                <?php endif; ?>
                                                                                                            <?php endif; ?>
                                                                                                        </div>
                                                                                                    </li>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            </ul>
                                                                                        <?php endif; ?>
                                                                                    </li>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </ul>
                                                                        <?php endif; ?>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </li>
</ul>
</li>
</ul>



                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->startSection('treeflex_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/treeflex2.css')); ?>">
<?php $__env->stopSection(); ?>




<?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/partials/tabtree.blade.php ENDPATH**/ ?>