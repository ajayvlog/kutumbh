<?php $__env->startSection('subtitle', trans('user.profile')); ?>

<?php $__env->startSection('user-content'); ?>
    <div class="row">
        <?php echo $__env->make('users.partials.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ext_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/plugins/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/plugins/jquery.datetimepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ext_js'); ?>
<script src="<?php echo e(asset('js/plugins/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/jquery.datetimepicker.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
(function () {
    $('select').select2();
    $('input[name=marriage_date]').datetimepicker({
        timepicker:false,
        format:'Y-m-d',
        closeOnDateSelect: true,
        scrollInput: false
    });
})();

(function() {
        $('#date').datetimepicker({
            timepicker:false,
            format:'Y-m-d',
            closeOnDateSelect: true,
            scrollInput: false
        });
    })();
</script>
<script>
    // $("#add_media").click(function(){
    // $("p").hide();
    // });

    $("#add_media").click(function(){
    $("#formMedia").show();
    $("#addmedia").hide();
    });

    $("#add_notes").click(function(){
    $("#formNotes").show();
    $("#addnotes").hide();
    });

    //redirect to specific tab
    // $(document).ready(function () {
    //     $('#pills-tab a[href="#<?php echo e(old('tab')); ?>"]').tab('show')
    // });
    // $(document).ready(function () {
    //     $('a[data-toggle="pill"]').on('show.bs.tab', function(e) {
    //         localStorage.setItem('activeTab', $(e.target).attr('href'));
    //     });
    //     var activeTab = localStorage.getItem('activeTab');
    //     if(activeTab){
    //         $('#pills-tab a[href="' + activeTab + '"]').tab('show');
    //     }
    // });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/show.blade.php ENDPATH**/ ?>