<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="mb-2  text-dark col-12 border pt-2">
        <div class="row">
            <div class="col-3 col-md-1">
                <?php echo e(userPhoto($user, ['class' => 'img-fluid rounded-circle border'])); ?>

            </div>
            <div class="col-md-6 col-6">
                <span> <strong><?php echo e($user->name); ?></strong> </span><br><span><small><?php echo $__env->yieldContent('subtitle'); ?></small></span>
                <div> <small><?php if($user->yob): ?><?php echo e(__('Born')); ?> <?php echo e($user->yob); ?>, <?php endif; ?> <?php echo nl2br($user->address); ?></small> </div>
            </div> 
        </div> 
        <div class="row">
            <div class="col-12 border border-bottom-0 border-left-0 border-right-0 mt-2">
                <div class="pt-1">
                    <ul class="nav nav-pills" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="btn btn-primary btn-xs" href="<?php echo e(route('users.show',[$user->id])); ?>">Show Profile</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div> 
        <?php echo $__env->yieldContent('user-content'); ?>     
    </div>   
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/layouts/user-profile-wide.blade.php ENDPATH**/ ?>