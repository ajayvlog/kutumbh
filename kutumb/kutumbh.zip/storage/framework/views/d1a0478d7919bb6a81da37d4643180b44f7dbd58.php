<?php 
    $father = $user->father_id ? $user->father : null;
    $mother = $user->mother_id ? $user->mother : null;

    $fatherGrandpa = $father && $father->father_id ? $father->father : null;
    $fatherGrandma = $father && $father->mother_id ? $father->mother : null;

    $motherGrandpa = $mother && $mother->father_id ? $mother->father : null;
    $motherGrandma = $mother && $mother->mother_id ? $mother->mother : null;

    $gfchilds = $fatherGrandpa ? $fatherGrandpa->childs : '';
    $fchilds = $father ? $father->childs : '' ;

    $childs = $user->childs;
    $colspan = $childs->count();
    $colspan = $colspan < 4 ? 4 : $colspan;

    $siblings = $user->siblings();
?>

            <div class="row mb-3 border border-muted shadow-lg p-3 mb-5 bg-white rounded ">
                <div class="col-6 "> <h5> Relations</h5></div>
                
            </div>
            <!--Grand parents-->
            <?php if($fatherGrandpa || $fatherGrandma): ?>
            <div class="row ">
                <div class="col-12 mb-3">
                    <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                        <strong><?php echo e(__('Grand Parents')); ?></strong>
                    </a>
                    <span class="text-muted">(<?php echo e($fatherGrandpa ? '1' : '0'); ?>)</span>
                </div>
                <div class="col-12">
                    <div class="collapse" id="collapseExample">
                        <div class="row">
                            <div class="col-md-2">
                                <div class="row text-right">
                                    <div class="col-12"> <strong><?php echo e(__('Grand Parents')); ?> </strong> </div>
                                    <div class="col-12"> <small class="text-muted"> Preffered</small> </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <?php if($fatherGrandpa): ?>
                                    <div class="col-12 p-2 border">
                                        <div class="row">
                                            <div class="col-12 col-md-3">
                                                <?php echo e(userPhoto($fatherGrandpa, ['class' => 'img-fluid rounded-circle border'])); ?>

                                            </div>
                                            <div class="col-12 col-md-9 text-center text-lg-left">
                                                <div> <span class="text-muted"> <?php echo e(trans('user.grand_father')); ?></span> </div>
                                                <div> <strong><?php echo e($fatherGrandpa ? $fatherGrandpa->profileLink() : '?'); ?> </strong> </div>
                                                <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($fatherGrandpa->yob ? $fatherGrandpa->yob : '"Date Not Available"'); ?></small> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                        <div class="col-12 p-2 border">
                                            <div class="row">
                                                <div class="col-12 col-md-3">
                                                
                                                </div>
                                                <div class="col-12 col-md-9 text-center text-lg-left">
                                                    <div> <span class="text-muted"> <?php echo e(trans('user.grand_father')); ?></span> </div>
                                                    <div> <strong>No data Available </strong> </div>
                                                    <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e('"Date Not Available"'); ?></small> </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-12 p-2 ">
                                        <!-- first child starts -->
                                        <div class="row">
                                            <div class="col-12 mb-3">
                                                <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample2">
                                                    <strong><small>Show Children in Family</small></strong>
                                                </a>
                                                <span class="text-muted"> <small>(<?php echo e(count($gfchilds)); ?>)</small></span>
                                            </div>
                                        </div>
                                        <?php if($gfchilds): ?>
                                            <div class="collapse" id="collapseExample2">
                                                <?php $__currentLoopData = $gfchilds->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkedChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                    <?php $__currentLoopData = $chunkedChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-12 p-2 border bg-light">
                                                        <div class="row">
                                                            <div class="col-12 col-md-3">
                                                                <?php echo e(userPhoto($child, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                            </div>
                                                            <div class="col-12 col-md-9 text-center text-lg-left">
                                                                <div> <span class="text-muted"> <?php echo e($child->gender == 'F' ? __('Daughter') : __('Son')); ?></span> </div>
                                                                <div> <strong><?php echo e($child->profileLink()); ?> (<?php echo e($child->gender); ?>) </strong> </div>
                                                                <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($child->yob ? $child->yob : '"Date Not Available"'); ?></small> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(! $loop->last): ?>
                                                    <div class="clearfix"></div>
                                                    <?php endif; ?>                                            
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                                            </div>
                                        <?php endif; ?>
                                        <!-- first child ends -->
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2 p-0">
                                <div class="half-line position"> </div>
                            </div>
                            <?php if($fatherGrandma): ?>
                            <div class="col-md-4 pl-md-0">
                                <div class="p-2 border">
                                    <div class="row">
                                        <div class="col-12 col-md-3">
                                            <?php echo e(userPhoto($fatherGrandma, ['class' => 'img-fluid rounded-circle border'])); ?>

                                        </div>
                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                            <div> <span class="text-muted"> <?php echo e(trans('user.grand_mother')); ?></span> </div>
                                            <div> <strong><?php echo e($fatherGrandma ? $fatherGrandma->profileLink() : '?'); ?> </strong> </div>
                                            <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($fatherGrandma->yob ? $fatherGrandma->yob : '"Date Not Available"'); ?></small> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="col-md-4 pl-md-0">
                                <div class="p-2 border">
                                    <div class="row">
                                        <div class="col-12 col-md-3">
                                            
                                        </div>
                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                            <div> <span class="text-muted"> <?php echo e(trans('user.grand_mother')); ?></span> </div>
                                            <div> <strong>No Data Available </strong> </div>
                                            <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e('"Date Not Available"'); ?></small> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <?php endif; ?>
            <!--Grand parents ends-->
           
            <!--parents-->
            <?php if($father || $mother): ?>
            <div class="row border border-muted  p-3 mb-5  rounded jpbox2">
                <div class="col-12 mb-3">
                    <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">
                        <strong><?php echo e(__('Parents')); ?></strong>
                    </a>
                    <span class="text-muted">(<?php echo e($father ? '1' : '0'); ?>)</span>
                </div>
                <div class="col-12">
                    <div class="collapse show" id="collapseExample1">
                        <div class="row">
                            <div class="col-md-2">
                                <div class="row text-right">
                                    <div class="col-12"> <strong><?php echo e(__('Parents')); ?> </strong> </div>
                                    <div class="col-12"> <small class="text-muted"> Preffered</small> </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row jpbox1">
                                    <?php if($father): ?>
                                        <div class="col-12 p-2 border ">
                                            <div class="row ">
                                                <div class="col-12 col-md-3">
                                                    <?php echo e(userPhoto($father, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                </div>
                                                <div class="col-12 col-md-9 text-center text-lg-left">
                                                    <div> <span class="text-muted"> <?php echo e(trans('user.father')); ?></span> </div>
                                                    <div> <strong><?php echo e($father ? $father->profileLink() : '?'); ?> </strong> </div>
                                                    <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($father->yob ? $father->yob : '"Date Not Available"'); ?></small> </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="col-12 p-2 border">
                                            <div class="row">
                                                <div class="col-12 col-md-3">
                                                    
                                                </div>
                                                <div class="col-12 col-md-9 text-center text-lg-left">
                                                    <div> <span class="text-muted"> <?php echo e(trans('user.father')); ?></span> </div>
                                                    <div> <strong>No Data Available</strong> </div>
                                                    <div> <small class="text-muted"><?php echo e(__('Born')); ?>.<?php echo e("Date Not Available"); ?></small> </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>                                    
                                    <div class="col-12 p-2 ">
                                        <!-- first child starts -->
                                        <div class="row jpbox2">
                                            <div class="col-12 mb-3">
                                                <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapsePchild" role="button" aria-expanded="false" aria-controls="collapsePchild">
                                                    <strong><small>Show Children in Family</small></strong>
                                                </a>
                                                <span class="text-muted"> <small>(<?php echo e(count($fchilds)); ?>)</small></span>
                                            </div>
                                        </div>
                                        <?php if($fchilds): ?>
                                            <div class="collapse" id="collapsePchild">
                                                <?php $__currentLoopData = $fchilds->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkedChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                    <?php $__currentLoopData = $chunkedChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-12 p-2 border bg-light">
                                                        <div class="row">
                                                            <div class="col-12 col-md-3">
                                                                <?php echo e(userPhoto($child, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                            </div>
                                                            <div class="col-12 col-md-9 text-center text-lg-left">
                                                                <div> <span class="text-muted"> <?php echo e($child->gender == 'F' ? __('Daughter') : __('Son')); ?></span> </div>
                                                                <div> <strong><?php echo e($child->profileLink()); ?> (<?php echo e($child->gender); ?>) </strong> </div>
                                                                <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($child->yob ? $child->yob : '"Date Not Available"'); ?></small> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(! $loop->last): ?>
                                                    <div class="clearfix"></div>
                                                    <?php endif; ?>                                            
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                                            </div>
                                        <?php endif; ?>
                                        <!-- first child ends -->
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2 p-0">
                                <div class="half-line position"> </div>
                            </div>
                            <?php if($mother): ?>
                                <div class="col-md-4 pl-md-0 jpbox1">
                                    <div class="p-2 border">
                                        <div class="row">
                                            <div class="col-12 col-md-3">
                                                <?php echo e(userPhoto($mother, ['class' => 'img-fluid rounded-circle border'])); ?>

                                            </div>
                                            <div class="col-12 col-md-9 text-center text-lg-left">
                                                <div> <span class="text-muted"> <?php echo e(trans('user.mother')); ?></span> </div>
                                                <div> <strong><?php echo e($mother ? $mother->profileLink() : '?'); ?> </strong> </div>
                                                <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($mother->yob ? $mother->yob : '"Date Not Available"'); ?></small> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="col-12 p-2 border">
                                    <div class="row">
                                        <div class="col-12 col-md-3">
                                            
                                        </div>
                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                            <div> <span class="text-muted"> <?php echo e(trans('user.father')); ?></span> </div>
                                            <div> <strong>No Data Available</strong> </div>
                                            <div> <small class="text-muted"><?php echo e(__('Born')); ?>.<?php echo e("Date Not Available"); ?></small> </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <?php endif; ?>
            <!--parents ends-->           
            <!--//spose-->
            <div class="row ">
                <div class="col-12 mb-3  jpbox1">
                    <a class="add-custom-icon text-dark jpbox1" data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="true" aria-controls="collapseExample3">
                        <strong><?php echo e(__('Spouse and Me')); ?></strong>
                    </a>
                    <span class="text-muted">(<?php echo e($user ? '1' : '0'); ?>)</span>
                </div>
                <div class="col-12 ">
                    <div class="collapse show" id="collapseExample3">
                        <div class="row jpbox1">
                            <div class="col-md-2">
                                <div class="row text-right">
                                    <div class="col-12"> <strong><?php echo e(__('Spouse and Me')); ?> </strong> </div>
                                    <div class="col-12"> <small class="text-muted"> Preffered</small> </div>
                                </div>
                            </div>
                            <div class="col-md-4 jpbox1">
                                <div class="row">
                                    <div class="col-12 p-2 border">
                                        <div class="row">
                                            <div class="col-12 col-md-3">
                                                <?php echo e(userPhoto($user, ['class' => 'img-fluid rounded-circle border'])); ?>

                                            </div>
                                            <div class="col-12 col-md-9 text-center text-lg-left">
                                                <div> <span class="text-muted"> <?php echo e(__('Me')); ?></span> </div>
                                                <div> <strong><?php echo e($user->profileLink('chart')); ?></strong> </div>
                                                <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($user->yob ? $user->yob : '"Date Not Available"'); ?></small> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 p-2 ">
                                        <!-- efefef -->
                                        <div class="row">
                                            <div class="col-12 mb-3">
                                                <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseExample4" role="button" aria-expanded="false" aria-controls="collapseExample4">
                                                    <strong><small>Show Children in Family in this Family</small></strong>
                                                </a>
                                                <span class="text-muted"> <small>(<?php echo e(count($childs)); ?>)</small></span>
                                            </div>
                                        </div>
                                        <?php if($childs): ?>
                                            <div class="collapse" id="collapseExample4">
                                                <?php $__currentLoopData = $childs->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkedChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                
                                                    <?php $__currentLoopData = $chunkedChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-12 p-2 border bg-light">
                                                        <div class="row">
                                                            <div class="col-12 col-md-3">
                                                                <?php echo e(userPhoto($child, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                            </div>
                                                            <div class="col-12 col-md-9 text-center text-lg-left">
                                                                <div> <span class="text-muted"> <?php echo e($child->gender == 'F' ? __('Daughter') : __('Son')); ?></span> </div>
                                                                <div> <strong><?php echo e($child->profileLink()); ?> (<?php echo e($child->gender); ?>) </strong> </div>
                                                                <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($child->yob ? $child->yob : '"Date Not Available"'); ?></small> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(! $loop->last): ?>
                                                    <div class="clearfix"></div>
                                                    <?php endif; ?>                                            
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                                            </div>
                                        <?php endif; ?>
                                        <!-- efefef -->
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2 p-0 ">
                                <div class="half-line position"> </div>
                            </div>
                            <div class="col-md-4 pl-md-0">
                                <?php if($user->gender_id == 1): ?>
                                    <?php if($user->wifes->isEmpty() == false): ?>
                                        <?php $__currentLoopData = $user->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="p-2 border">
                                                <div class="row">
                                                    <div class="col-12 col-md-3">
                                                        <?php echo e(userPhoto($wife, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                    </div>
                                                    <div class="col-12 col-md-9 text-center text-lg-left">
                                                        <div> <span class="text-muted"> <?php echo e(__('user.spouse')); ?></span> </div>
                                                        <div> <strong><?php echo e($wife->profileLink()); ?> </strong> </div>
                                                        <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($wife->yob ? $wife->yob : '"Date Not Available"'); ?></small> </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <div class="p-2 border jpbox1">
                                            <div class="row jpbox1">
                                                <div class="col-12 col-md-3">
                                                    
                                                </div>
                                                <div class="col-12 col-md-9 text-center text-lg-left">
                                                    <div> <span class="text-muted"> <?php echo e(__('user.spouse')); ?></span> </div>
                                                    <div> <strong><?php echo e(__('No Data Available')); ?> </strong> </div>
                                                    <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e(__('Date Not Available')); ?></small> </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php elseif($user->husbands->isEmpty() == false): ?>
                                    <?php $__currentLoopData = $user->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="p-2 border">
                                            <div class="row">
                                                <div class="col-12 col-md-3">
                                                    <?php echo e(userPhoto($husband, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                </div>
                                                <div class="col-12 col-md-9 text-center text-lg-left">
                                                    <div> <span class="text-muted"> <?php echo e(__('user.spouse')); ?></span> </div>
                                                    <div> <strong><?php echo e($husband->profileLink()); ?> </strong> </div>
                                                    <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($husband->yob ? $husband->yob : '"Date Not Available"'); ?></small> </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="p-2 border">
                                        <div class="row">
                                            <div class="col-12 col-md-3">
                                                
                                            </div>
                                            <div class="col-12 col-md-9 text-center text-lg-left">
                                                <div> <span class="text-muted"> <?php echo e(__('user.spouse')); ?></span> </div>
                                                <div> <strong><?php echo e(__('No Data Available')); ?> </strong> </div>
                                                <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e(__('Date Not Available')); ?></small> </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--//spose ends-->

            <?php if($siblings): ?>
                <hr>
                <!--//Siblings-->
                <div class="row">
                    <div class="col-12 mb-3">
                        <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseExample5" role="button" aria-expanded="true" aria-controls="collapseExample5">
                            <strong><?php echo e(trans('user.siblings')); ?></strong>
                        </a>
                        <span class="text-muted">(<?php echo e(count($siblings)); ?>)</span>
                    </div>
                    <div class="col-12">
                        <div class="collapse" id="collapseExample5">
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="row text-right">
                                        <div class="col-12"> <strong><?php echo e(trans('user.siblings')); ?> </strong> </div>
                                        <div class="col-12"> <small class="text-muted"> Preffered</small> </div>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $siblings->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkedSiblings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $chunkedSiblings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sibling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    
                                    <?php if($key!=0 && ($key%2)==0 ): ?>
                                        <div class="col-md-2" style="margin-left: 0.1em;"></div>
                                    <?php endif; ?>
                                        <div class="col-md-4">
                                            <div class="row">
                                                <div class="col-12 p-2 border">
                                                    <div class="row">
                                                        <div class="col-12 col-md-3">
                                                            <?php echo e(userPhoto($sibling, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                        </div>
                                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                                            <div> <span class="text-muted"> <?php echo e(trans('user.siblings')); ?></span> </div>
                                                            <div> <strong><?php echo e($sibling->profileLink()); ?> (<?php echo e($sibling->gender); ?>)</strong> </div>
                                                            <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($sibling->yob ? $sibling->yob : '"Date Not Available"'); ?></small> </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 p-2 ">
                                                    <!-- efefef -->
                                                    <div class="row">
                                                        <div class="col-12 mb-3">
                                                            <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseExample6" role="button" aria-expanded="false" aria-controls="collapseExample6">
                                                                <strong><small>Show Children in Family in this Family</small></strong>
                                                            </a>
                                                            <span class="text-muted"> <small>(<?php echo e(count($sibling->childs)); ?>)</small></span>
                                                        </div>
                                                    </div>

                                                    <?php if($sibling->childs): ?>
                                                        <div class="collapse show" id="collapseExample6" style="margin-left: 1em;">
                                                            <?php $__currentLoopData = $sibling->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="col-12 p-2 border bg-light" >
                                                                    <div class="row">
                                                                        <div class="col-12 col-md-3">
                                                                            <?php echo e(userPhoto($child, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                                        </div>
                                                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                                                            <div> <span class="text-muted"> <?php echo e($child->gender == 'F' ? __('Daughter') : __('Son')); ?></span> </div>
                                                                            <div> <strong><?php echo e($child->profileLink()); ?> (<?php echo e($child->gender); ?>) </strong> </div>
                                                                            <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($child->yob ? $child->yob : '"Date Not Available"'); ?></small> </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <?php if(! $loop->last): ?>
                                                                <div class="clearfix"></div>
                                                                <?php endif; ?>
                                                                <?php if($child->childs): ?>
                                                                    <div class="col-12 p-2 ">
                                                                        <!-- efefef -->
                                                                        <div class="row">
                                                                            <div class="col-12 mb-3">
                                                                                <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseExample7" role="button" aria-expanded="false" aria-controls="collapseExample7">
                                                                                    <strong><small>Show Children in Family in this Family</small></strong>
                                                                                </a>
                                                                                <span class="text-muted"> <small>(<?php echo e(count($child->childs)); ?>)</small></span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="collapse show" id="collapseExample7">
                                                                            <?php $__currentLoopData = $child->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <div class="col-12 p-2 border bg-light" style="margin-left: 1em;">
                                                                                    <div class="row">
                                                                                        <div class="col-12 col-md-3">
                                                                                            <?php echo e(userPhoto($grand, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                                                        </div>
                                                                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                                                                            <div> <span class="text-muted"> <?php echo e($grand->gender == 'F' ? __('Daughter') : __('Son')); ?></span> </div>
                                                                                            <div> <strong><?php echo e($grand->profileLink()); ?> (<?php echo e($grand->gender); ?>) </strong> </div>
                                                                                            <div> <small class="text-muted"><?php echo e(__('Born')); ?> <?php echo e($grand->yob ? $grand->yob : '"Date Not Available"'); ?></small> </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                 <?php if(! $loop->last): ?>
                                                                                <div class="clearfix"></div>
                                                                                <?php endif; ?>                                           
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                                                                        </div>
                                                                        <!-- efefef -->
                                                                    </div><hr>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                                                        </div>
                                                    <?php endif; ?>
                                                    <!-- efefef -->
                                                </div>                                                
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!--//siblings ends-->
            <?php endif; ?><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/partials/tabchart.blade.php ENDPATH**/ ?>