<?php $__env->startSection('content'); ?>
<?php if(request('action') == 'delete' && $user): ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $user)): ?>
    <link rel="stylesheet" href="https://jainismjdp.com/test/css/plugins/select2.min.css">
    
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default">
                    <div class="panel-heading"><h3 class="panel-title"><?php echo e(__('user.delete')); ?> : <?php echo e($user->name); ?></h3></div>
                    <div class="panel-body">
                        <table class="table table-condensed">
                            <tr><td><?php echo e(__('user.name')); ?></td><td><?php echo e($user->name); ?></td></tr>
                            <tr><td><?php echo e(__('user.nickname')); ?></td><td><?php echo e($user->nickname); ?></td></tr>
                            <tr><td><?php echo e(__('user.gender')); ?></td><td><?php echo e($user->gender); ?></td></tr>
                            <tr><td><?php echo e(__('user.father')); ?></td><td><?php echo e($user->father_id ? $user->father->name : ''); ?></td></tr>
                            <tr><td><?php echo e(__('user.mother')); ?></td><td><?php echo e($user->mother_id ? $user->mother->name : ''); ?></td></tr>
                            <tr><td><?php echo e(__('user.childs_count')); ?></td><td><?php echo e($childsCount = $user->childs()->count()); ?></td></tr>
                            <tr><td><?php echo e(__('user.spouses_count')); ?></td><td><?php echo e($spousesCount = $user->marriages()->count()); ?></td></tr>
                            <tr><td><?php echo e(__('user.managed_user')); ?></td><td><?php echo e($managedUserCount = $user->managedUsers()->count()); ?></td></tr>
                            <tr><td><?php echo e(__('user.managed_couple')); ?></td><td><?php echo e($managedCoupleCount = $user->managedCouples()->count()); ?></td></tr>
                        </table>
                        <?php if($childsCount + $spousesCount + $managedUserCount + $managedCoupleCount): ?>
                            <?php echo e(__('user.replace_delete_text')); ?>

                            <?php echo e(Form::open([
                                'route' => ['users.destroy', $user],
                                'method' => 'delete',
                                'onsubmit' => 'return confirm("'.__('user.replace_confirm').'")',
                            ])); ?>

                            <?php echo FormField::select('replacement_user_id', $replacementUsers, [
                                'label' => false,
                                'placeholder' => __('user.replacement'),
                            ]); ?>

                            <?php echo e(Form::submit(__('user.replace_delete_button'), [
                                'name' => 'replace_delete_button',
                                'class' => 'btn btn-danger',
                            ])); ?>

                            <?php echo e(link_to_route('users.edit', __('app.cancel'), [$user], ['class' => 'btn btn-default pull-right'])); ?>

                            <?php echo e(Form::close()); ?>

                        <?php else: ?>
                            <?php echo FormField::delete(
                                ['route' => ['users.destroy', $user]],
                                __('user.delete_confirm_button'),
                                ['class' => 'btn btn-danger'],
                                ['user_id' => $user->id]
                            ); ?>

                            <?php echo e(link_to_route('users.edit', __('app.cancel'), [$user], ['class' => 'btn btn-default'])); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php else: ?>
<div class="container-fluid mt-3">
    <div class="mb-2  text-dark col-12 border pt-2">
        <div class="row mb-6">
            <div class="col-6"> <h5> <?php echo e($user->profileLink()); ?> <small>(<?php echo e(__('user.edit')); ?>)</small></h5></div>
            
            <ul class="nav nav-pills" id="pills-tab" role="tablist">
                <li class="nav-item">
                    <?php echo e(link_to_route('users.show', __('app.show_profile').' '.$user->name, [$user->id], ['class' => 'nav-link active'])); ?>

                </li> &nbsp;
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $user)): ?>
                <li><?php echo e(link_to_route('users.edit', __('user.delete'), [$user, 'action' => 'delete'], ['class' => 'btn btn-danger pull-right', 'id' => 'del-user-'.$user->id])); ?></li>
                <?php endif; ?>
            </ul>
            
        </div>
    </div><div class="col-12">
    <div class="row">
        <div class="mb-2 text-dark col-9 border pt-2">
            <div class="row">
                <div class="col-md-4 jpbox1 border border-muted rounded p-1 m-1">
                    <?php echo e(Form::model($user, ['route' => ['users.update', $user->id], 'method' =>'patch', 'autocomplete' => 'off'])); ?>

                    <div class="panel panel-default">
                        <div class="panel-heading"><u><h5 class="panel-title"><?php echo e(__('Personal Details')); ?></h5></u></div>
                        <div class="panel-body">
                            <?php echo FormField::text('name', ['label' => __('user.name')]); ?>

                            <?php echo FormField::text('nickname', ['label' => __('user.nickname')]); ?>

                            <div class="row">
                                <div class="col-md-6"><?php echo FormField::radios('gender_id', [1 => __('app.male_code'), __('app.female_code')], ['label' => __('user.gender')]); ?></div>
                                <div class="col-md-4">
                                    <?php echo FormField::text('birth_order', ['label' => __('user.birth_order'), 'type' => 'number', 'min' => 1]); ?>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6"><?php echo FormField::text('pob', ['label' => __('Place of Birth'), 'placeholder' => __('Place Of Birth')]); ?></div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="tob">Time of Birth:</label>
                                        <input type="time" name="tob" id="time" class="form-control" value="<?php echo e($user->tob); ?>" placeholder="Time of Birth"/>
                                    </div>
                                </div>
                                
                                

                                <div class="col-md-6"><?php echo FormField::text('yob', ['label' => __('user.yob'), 'placeholder' => __('app.example').' 1959']); ?></div>
                                <div class="col-md-6"><?php echo FormField::text('dob', ['label' => __('user.dob'), 'placeholder' => __('app.example').' 1959-07-20']); ?></div>
                            </div>
                            


<?php if($user->id !=$user->manager_id): ?>
                            <div class="row" id='dod'>
                                <div class="col-md-6"><?php echo FormField::text('yod', ['label' => __('user.yod'), 'placeholder' => __('app.example').' 2003']); ?></div>
                                <div class="col-md-6"><?php echo FormField::text('dod', ['label' => __('user.dod'), 'placeholder' => __('app.example').' 2003-10-17']); ?></div>
                            </div>
           
<?php endif; ?>
                               
                            
                        </div>
                    </div>
                    <hr>
                    <div class="panel panel-default">
                        <div class="panel-heading"><u><h5 class="panel-title"><?php echo e(__('app.login_account')); ?></h5></u></div>
                        <div class="panel-body">
                            <?php echo FormField::email('email', ['label' => __('auth.email'), 'placeholder' => __('app.example').' nama@mail.com']); ?>

                              </div>
                    </div>
                </div>
                <div class="col-md-3 jpbox1 border border-muted rounded p-1 m-1 tooltipLink" data-tooltip="<?php echo e(__('Religions Panel')); ?>" title="<?php echo e(__('Religions Panel')); ?>">
                    <div class="panel panel-default">
                        <div class="panel-heading"><u><h5 class="panel-title"><?php echo e(__('Religions')); ?></h5></u></div>
                        <div class="panel-body">
                            
                            <div class="form-group d-none">
                                <label for="religion">Select Religion:</label>
                                <select name="relign_id" class="form-control">
                                    <option value="">--- Select Religion ---</option>
                                    <?php $__currentLoopData = $religions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == $user->relign_id ? 'selected':''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group d-none">
                                <label for="cast">Select Cast:</label>
                                <select name="cast_id" class="form-control">
                                    <option value="">--- Select Cast ---</option>
                                    <?php $__currentLoopData = $casts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == $user->cast_id ? 'selected':''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="dynasty">Select Dynasty:</label>
                                <select name="dynasty_id" class="form-control select22" id="dynasty">
                                    <option value="">--- Select Dynasty ---</option>
                                    <?php $__currentLoopData = $dynasties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == $user->dynasty_id ? 'selected':''); ?>><?php echo e($value); ?></option>
                                        <?php if($loop->last): ?>
                                        <option value="-1" <?php echo e(-1 == $user->dynasty_id ? 'selected':''); ?>>Others</option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <input type="text" name="dynasty_other" id="dynasty_other" style="display:none" value="<?php echo $user->dynasty_other; ?>">

                            <div class="form-group">
                                <label for="clan">Select Gotra:</label>
                                <select name="clan_id" class="form-control select22">
                                    <option value="">--- Select Gotra ---</option>
                                    <?php $__currentLoopData = $clans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == $user->clan_id ? 'selected':''); ?>><?php echo e($value); ?></option>
                                        <?php if($loop->last): ?>
                                        <option value="-1" <?php echo e(-1 == $user->clan_id ? 'selected':''); ?>>Others</option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <input type="text" name="clan_other" id="clan_other" style="display:none"  value="<?php echo $user->clan_other; ?>">

                            <div class="form-group">
                                <label for="subclan">Select Sub-Gotra:</label>
                                <select name="subclan_id" id="subclan_id" class="form-control select22">
                                    <option value="">--- Select Sub-Gotra ---</option>
                                        
                                        <option value="-1" <?php echo e(-1 == $user->subclan_id ? 'selected':''); ?>>Others</option>
                                       
                                </select>
                            </div>

                            <input type="text" name="subclan_other" id="subclan_other" style="display:none;" value="<?php echo $user->subclan_other; ?>">
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-4 jpbox1 border border-muted rounded p-1 m-1">
                    <div class="panel panel-default">
                        <div class="panel-heading"><u><h5 class="panel-title"><?php echo e(__('app.address')); ?> &amp; <?php echo e(__('app.contact')); ?></h5></u></div>
                        <div class="panel-body">
                            <?php echo FormField::text('phone', ['label' => __('app.phone'), 'placeholder' => __('app.example').' 081234567890']); ?>

                            <?php echo FormField::text('address', ['label' => __('Current Location')]); ?>                            
                            <div class="form-group">
                                <label for="country">Select Country:</label>
                                <select name="country_id" class="form-control select22">
                                    <option value="">--- Select Country ---</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == $user->country_id ? 'selected':''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="state">Select State:</label>
                                <select name="state_id" class="form-control  select22">
                                    <option value="">--- Select State ---</option>
                                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == $user->state_id ? 'selected':''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="city">Select City:</label>
                                <select name="city_id" class="form-control select22">
                                    <option value="">--- Select City ---</option>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == $user->city_id ? 'selected':''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="tehsil">Select Tehsil:</label>
                                <select name="tehsil_id" class="form-control select22">
                                    <option value="">--- Select Tehsil ---</option>
                                    <?php $__currentLoopData = $tehsils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == $user->tehsil_id ? 'selected':''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="village">Select Village:</label>
                                <select name="village_id" class="form-control select22">
                                    <option value="">--- Select Village ---</option>
                                    <?php $__currentLoopData = $villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == $user->village_id ? 'selected':''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>                
                    <hr>
                    <div class="text-right" style="margin-bottom: 1em;">
                        <?php echo e(Form::submit(__('app.update'), ['class' => 'btn btn-primary'])); ?>

                        <?php echo e(link_to_route('users.show', __('app.cancel'), [$user->id], ['class' => 'btn btn-danger'])); ?>

                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
        <div class="mb-2 text-dark col-3 border pt-2">
            <div class="panel panel-default">
                <div class="panel-heading"><h3 class="panel-title"><?php echo e(__('user.update_photo')); ?></h3></div>
                <?php echo e(Form::open(['route' => ['users.photo-upload', $user], 'method' => 'patch', 'files' => true])); ?>

                <div class="panel-body text-center">
                    <?php echo e(userPhoto($user, ['style' => 'width:100%;max-width:300px'])); ?>

                </div>
                <div class="panel-body">
                    <?php echo FormField::file('photo', ['required' => true, 'label' => __('user.reupload_photo'), 'info' => ['text' => 'Format jpg, maks: 200 Kb.', 'class' => 'warning']]); ?>

                </div>
                <div class="panel-footer">
                    <?php echo Form::submit(__('user.update_photo'), ['class' => 'btn btn-success']); ?>

                    <?php echo e(link_to_route('users.show', __('app.cancel'), [$user], ['class' => 'btn btn-danger'])); ?>

                </div>
                <?php echo e(Form::close()); ?>

            </div>
            
        </div>
    </div></div>
</div>





    
    
    
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ext_css'); ?>
<link href="<?php echo e(asset('css/plugins/jquery.datetimepicker.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/plugins/jquery.datetimepicker.js')); ?>"></script>
 
<script>
<?php if($user->id): ?>
let id = "<?php echo $user->dynasty_id; ?>";
dy(id); 
let clanid='<?php echo $user->clan_id; ?>';

if(clanid==-1)
{
    $('#clan_other').show();
}else{
    $('#clan_other').hide();
}

let subclan_id='<?php echo $user->subclan_id ?>';
if(subclan_id==-1)
{
    $('#subclan_other').show();
}else{
    $('#subclan_other').hide();
}
<?php endif; ?>
 
 
    $('#dynasty').change(function(){
        let id = $('#dynasty').val();
        dy(id);
    });

    function dy(id)
    {  $('#dynasty_other').hide(); 
       if(id=='-1')
        {
             
            $('#dynasty_other').show();
        }
    }
  
$('#subclan_id').change(function(){
let id = $('#subclan_id').val();
$('#subclan_other').hide(); 
if(id=='-1')
 {
      $('#subclan_other').show();
  }
});

    (function() {
        $('#dob,#dod').datetimepicker({
            timepicker:false,
            format:'Y-m-d',
            closeOnDateSelect: true,
            scrollInput: false
        });
    })();

    //$('$time').pickatime()
</script>
<script type="text/javascript">
 
    $(document).ready(function ()
     
    {
        jQuery('select[name="relign_id"]').on('change',function(){
            var relignID = jQuery(this).val();
            if(relignID)
            {
                jQuery.ajax({
                    url : 'getCast/'+relignID,
                    type : "GET",
                    dataType : "json",
                    success:function(data)
                    {
                        console.log(data);
                        jQuery('select[name="cast_id"]').empty();
                        jQuery.each(data, function(key,value){
                            $('select[name="cast_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }
            else
            {
                $('select[name="cast_id"]').empty();
            }
        });
    });

    function clanothers(clanID)
    {
        $('#clan_other').hide(); 
        if(clanID=='-1')
        {
        $('#clan_other').show();
        }
    }

    $(document).ready(function ()
    {   
        jQuery('select[name="clan_id"]').on('change',function(){
        var clanID = jQuery(this).val();
      
        clanothers(clanID);
        if(clanID)
            {
                //$("#subclan_id").select2('destroy'); 
                jQuery('select[name="subclan_id"]').empty();
             
                jQuery.ajax({
                    url : 'getSubclan/'+clanID,
                    type : "GET",
                    dataType : "json",
                    success:function(data)
                    {
                        console.log(data);
                       
                        jQuery.each(data, function(key,value){
                            $('select[name="subclan_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }
            else
            {
             jQuery('select[name="subclan_id"]').empty();
            
            }

            $('select[name="subclan_id"]').append('<option value="-1">Others</option>');
});
});

    $(document).ready(function ()
    {
        jQuery('select[name="country_id"]').on('change',function(){
            var countryID = jQuery(this).val();
            if(countryID)
            {
                jQuery.ajax({
                    url : 'getState/'+countryID,
                    type : "GET",
                    dataType : "json",
                    success:function(data)
                    {
                        console.log(data);
                        jQuery('select[name="state_id"]').empty();
                        jQuery.each(data, function(key,value){
                            $('select[name="state_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }
            else
            {
                $('select[name="state_id"]').empty();
            }
        });
    });

    $(document).ready(function ()
    {
        jQuery('select[name="state_id"]').on('change',function(){
            var stateID = jQuery(this).val();
            if(stateID)
            {
                jQuery.ajax({
                    url : 'getCity/'+stateID,
                    type : "GET",
                    dataType : "json",
                    success:function(data)
                    {
                        console.log(data);
                        jQuery('select[name="city_id"]').empty();
                        jQuery.each(data, function(key,value){
                            $('select[name="city_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }
            else
            {
                $('select[name="city_id"]').empty();
            }
        });
    });

    $(document).ready(function ()
    {
        jQuery('select[name="city_id"]').on('change',function(){
            var cityID = jQuery(this).val();
            if(cityID)
            {
                jQuery.ajax({
                    url : 'getTehsil/'+cityID,
                    type : "GET",
                    dataType : "json",
                    success:function(data)
                    {
                        console.log(data);
                        jQuery('select[name="tehsil_id"]').empty();
                        jQuery.each(data, function(key,value){
                            $('select[name="tehsil_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }
            else
            {
                $('select[name="tehsil_id"]').empty();
            }
        });
    });

    $(document).ready(function ()
    {
        jQuery('select[name="tehsil_id"]').on('change',function(){
            var tehsilID = jQuery(this).val();
            if(tehsilID)
            {
                jQuery.ajax({
                    url : 'getVillage/'+tehsilID,
                    type : "GET",
                    dataType : "json",
                    success:function(data)
                    {
                        console.log(data);
                        jQuery('select[name="village_id"]').empty();
                        jQuery.each(data, function(key,value){
                            $('select[name="village_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }
            else
            {
                $('select[name="village_id"]').empty();
            }
        });
    });
    
  $(document).ready(function() {
     $('.select22').select2();   
});
  
    
    
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/edit.blade.php ENDPATH**/ ?>