<div class="col-md-6">
    <div class="p-3 border mt-3">
        <div class="row mb-3">
            <div class="col-6"> <h5> Relations</h5></div>
            
        </div>
        <div class="row">
            <div class="col-12 mb-3">
                <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="true" aria-controls="collapseExample">
                    <strong><?php echo e(__('user.parent')); ?></strong>
                </a>

                <span class="text-muted">(<?php echo e($user->parents->count()); ?>)</span>
                
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="collapse show" id="collapseExample">
                    <div class="row">
                        <div class="col-12">
                            <div class="input-group">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $user)): ?>
                                    <?php if(request('action') == 'set_father'): ?>
                                    <?php echo e(Form::open(['route' => ['family-actions.set-father', $user->id]])); ?>

                                    <?php echo FormField::select('set_father_id', $malePersonList, ['label' => false, 'value' => $user->father_id, 'placeholder' => __('app.select_from_existing_males')]); ?>

                                    <div class="input-group">
                                        <?php echo e(Form::text('set_father', null, ['class' => 'form-control input-sm', 'placeholder' => __('app.enter_new_name')])); ?>

                                        <span class="input-group-btn">
                                            <?php echo e(Form::submit(__('app.update'), ['class' => 'btn btn-info btn-sm', 'id' => 'set_father_button'])); ?>

                                            <?php echo e(link_to_route('users.show', __('app.cancel'), [$user->id], ['class' => 'btn btn-default btn-sm'])); ?>

                                        </span>
                                    </div>
                                    <?php echo e(Form::close()); ?>

                                    <?php elseif( $user->fatherLink()): ?>
                                        <div class="col-12 col-md-3">
                                            <?php echo e(userPhoto($user->father, ['class' => 'img-fluid rounded-circle border'])); ?>

                                        </div>
                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                            <div> <span class="text-muted"><?php echo e(__('user.father')); ?></span> </div>
                                            <div> <strong><?php echo e($user->fatherLink()); ?></strong> </div>
                                            <?php if($user->father->yob): ?>
                                                <div> <small class="text-muted"> <?php echo e(trans('user.dob')); ?> <?php echo e($user->father->yob); ?></small> </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('users.show', [$user->id, 'action' => 'set_father'] )); ?>" class="addLink"><i class="fas fa-plus-circle"></i></a>
                                        <div class="input-group-append">
                                            <span class="mt-3 ml-2"> <small>Add Father</small></span>
                                        </div>
                                    <?php endif; ?>
                                    <?php else: ?>
                                        <?php if( $user->fatherLink()): ?>
                                            <div class="col-12 col-md-3">
                                                <?php echo e(userPhoto($user->father, ['class' => 'img-fluid rounded-circle border'])); ?>

                                            </div>
                                            <div class="col-12 col-md-9 text-center text-lg-left">
                                                <div> <span class="text-muted"><?php echo e(__('user.father')); ?></span> </div>
                                                <div> <strong><?php echo e($user->fatherLink()); ?></strong> </div>
                                                <?php if($user->father->yob): ?>
                                                    <div> <small class="text-muted"> <?php echo e(trans('user.dob')); ?> <?php echo e($user->father->yob); ?></small> </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                            <div> <strong><?php echo e(__('"Father Record is not Found"')); ?></strong> </div>
                                        </div>
                                        <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $user)): ?>
                                    <?php if(request('action') == 'set_mother'): ?>
                                    <?php echo e(Form::open(['route' => ['family-actions.set-mother', $user->id]])); ?>

                                    <?php echo FormField::select('set_mother_id', $femalePersonList, ['label' => false, 'value' => $user->mother_id, 'placeholder' => __('app.select_from_existing_females')]); ?>

                                    <div class="input-group">
                                        <?php echo e(Form::text('set_mother', null, ['class' => 'form-control input-sm', 'placeholder' => __('app.enter_new_name')])); ?>

                                        <span class="input-group-btn">
                                            <?php echo e(Form::submit(__('app.update'), ['class' => 'btn btn-info btn-sm', 'id' => 'set_mother_button'])); ?>

                                            <?php echo e(link_to_route('users.show', __('app.cancel'), [$user->id], ['class' => 'btn btn-default btn-sm'])); ?>

                                        </span>
                                    </div>
                                    <?php echo e(Form::close()); ?>

                                    <?php elseif( $user->motherLink()): ?>
                                        <div class="col-12 col-md-3">
                                            <?php echo e(userPhoto($user->mother, ['class' => 'img-fluid rounded-circle border'])); ?>

                                        </div>
                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                            <div> <span class="text-muted"><?php echo e(__('user.mother')); ?></span> </div>
                                            <div> <strong><?php echo e($user->motherLink()); ?></strong> </div>
                                            <?php if($user->mother->yob): ?>
                                                <div> <small class="text-muted"> <?php echo e(trans('user.dob')); ?> <?php echo e($user->mother->yob); ?></small> </div>
                                            <?php endif; ?>
                                        </div>                                        
                                    <?php else: ?>
                                        <a href="<?php echo e(route('users.show', [$user->id, 'action' => 'set_mother'] )); ?>" class="addLink"><i class="fas fa-plus-circle"></i></a>
                                        <div class="input-group-append">
                                            <span class="mt-3 ml-2"> <small>Add Mother</small></span>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if( $user->motherLink()): ?>
                                        <div class="col-12 col-md-3">
                                            <?php echo e(userPhoto($user->mother, ['class' => 'img-fluid rounded-circle border'])); ?>

                                        </div>
                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                            <div> <span class="text-muted"><?php echo e(__('user.mother')); ?></span> </div>
                                            <div> <strong><?php echo e($user->motherLink()); ?></strong> </div>
                                            <?php if($user->mother->yob): ?>
                                                <div> <small class="text-muted"> <?php echo e(trans('user.dob')); ?> <?php echo e($user->mother->yob); ?></small> </div>
                                            <?php endif; ?>
                                        </div> 
                                    <?php else: ?>
                                        <div class="col-12 col-md-9 text-center text-lg-left">
                                            <div> <strong><?php echo e(__('"Mother record is not found"')); ?></strong> </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr>
            <div class="row">
                <div class="col-12 mb-3">
                    <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="true" aria-controls="collapseExample1">
                        <strong><?php echo e(__('Spouse And Child')); ?></strong>
                    </a>

                    
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="collapse show" id="collapseExample1">
                        <div class="row">                           
                            <div class="col-12">
                                <div class="input-group">
                                    <?php if($user->gender_id == 1): ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $user)): ?>
                                            <?php if(request('action') == 'add_spouse'): ?>
                                                <div>
                                                    <?php echo e(Form::open(['route' => ['family-actions.add-wife', $user->id]])); ?>

                                                    <?php echo FormField::select('set_wife_id', $femalePersonList, ['label' => false, 'placeholder' => __('app.select_from_existing_females')]); ?>

                                                    <div class="form-group">
                                                        <div class="row">
                                                            <div class="col-md-7">
                                                                <?php echo e(Form::text('set_wife', null, ['class' => 'form-control input-sm', 'placeholder' => __('app.enter_new_name')])); ?>

                                                            </div>
                                                            <div class="col-md-5">
                                                                <?php echo e(Form::text('marriage_date', null, ['class' => 'form-control input-sm', 'placeholder' => __('couple.marriage_date')])); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php echo e(Form::submit(__('app.update'), ['class' => 'btn btn-info btn-sm', 'id' => 'set_wife_button'])); ?>

                                                    <?php echo e(link_to_route('users.show', __('app.cancel'), $user, ['class' => 'btn btn-default btn-sm'])); ?>

                                                    <?php echo e(Form::close()); ?>

                                                </div>
                                            <?php elseif($user->wifes->isEmpty() == false): ?>
                                                <?php $__currentLoopData = $user->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-12 col-md-3">
                                                        <?php echo e(userPhoto($wife, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                    </div>

                                                    <div class="col-12 col-md-9 text-center text-lg-left">
                                                        <div> <span class="text-muted"> <?php echo e(__('user.spouse')); ?></span> </div>
                                                        <div> <strong><?php echo e($wife->profileLink()); ?></strong> </div>
                                                        <?php if($wife->yob): ?>
                                                            <div> <small class="text-muted"><?php echo e(trans('user.dob')); ?> <?php echo e($wife->yob); ?></small> </div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                                        
                                            <?php else: ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $user)): ?>
                                                    <div class="pull-right">
                                                        <?php if (! (request('action') == 'add_spouse')): ?>
                                                            <a href="<?php echo e(route('users.show', [$user->id, 'action' => 'add_spouse'] )); ?>" class="addLink"><i class="fas fa-plus-circle"></i></a>
                                                            <div class="input-group-append">
                                                                <span class="mt-3 ml-2"> <small>Add Wife</small></span>
                                                            </div>                                                            
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>                                                    
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <?php if($user->wifes->isEmpty() == false): ?>
                                                <?php $__currentLoopData = $user->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-12 col-md-3">
                                                        <?php echo e(userPhoto($wife, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                    </div>

                                                    <div class="col-12 col-md-9 text-center text-lg-left">
                                                        <div> <span class="text-muted"> <?php echo e(__('user.spouse')); ?></span> </div>
                                                        <div> <strong><?php echo e($wife->profileLink()); ?></strong> </div>
                                                        <?php if($wife->yob): ?>
                                                            <div> <small class="text-muted"><?php echo e(trans('user.dob')); ?> <?php echo e($wife->yob); ?></small> </div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <div class="col-12 col-md-9 text-center text-lg-left">
                                                    <div> <strong><?php echo e(__('Wife Record Not Found')); ?></strong> </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?> 
                                    <?php else: ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $user)): ?>
                                            <?php if(request('action') == 'add_spouse'): ?>
                                                <div>
                                                    <?php echo e(Form::open(['route' => ['family-actions.add-husband', $user->id]])); ?>

                                                    <?php echo FormField::select('set_husband_id', $malePersonList, ['label' => false, 'placeholder' => __('app.select_from_existing_males')]); ?>

                                                    <div class="form-group">
                                                        <div class="row">
                                                            <div class="col-md-7">
                                                                <?php echo e(Form::text('set_husband', null, ['class' => 'form-control input-sm', 'placeholder' => __('app.enter_new_name')])); ?>

                                                            </div>
                                                            <div class="col-md-5">
                                                                <?php echo e(Form::text('marriage_date', null, ['class' => 'form-control input-sm', 'placeholder' => __('couple.marriage_date')])); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php echo e(Form::submit(__('app.update'), ['class' => 'btn btn-info btn-sm', 'id' => 'set_husband_button'])); ?>

                                                    <?php echo e(link_to_route('users.show', __('app.cancel'), [$user->id], ['class' => 'btn btn-default btn-sm'])); ?>

                                                    <?php echo e(Form::close()); ?>

                                                </div>
                                            <?php elseif($user->husbands->isEmpty() == false): ?>
                                                <?php $__currentLoopData = $user->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-12 col-md-3">
                                                        <?php echo e(userPhoto($husband, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                    </div>

                                                    <div class="col-12 col-md-9 text-center text-lg-left">
                                                        <div> <span class="text-muted"> <?php echo e(__('user.spouse')); ?></span> </div>
                                                        <div> <strong><?php echo e($husband->profileLink()); ?></strong> </div>
                                                        <?php if($husband->yob): ?>
                                                            <div> <small class="text-muted"><?php echo e(trans('user.dob')); ?> <?php echo e($husband->yob); ?></small> </div>
                                                        <?php endif; ?>
                                                    </div>                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                                        
                                            <?php else: ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $user)): ?>
                                                    <div class="pull-right" >
                                                        <?php if (! (request('action') == 'add_spouse')): ?>
                                                        <?php if(Auth::user()->gender_id): ?>
                                                            <a href="<?php echo e(route('users.show', [$user->id, 'action' => 'add_spouse'] )); ?>" class="addLink" id="check_gender"><i class="fas fa-plus-circle"></i></a>
                                                            <div class="input-group-append">
                                                                <span class="mt-3 ml-2"> <small>Add Husband <?php echo e((Auth::user()->gender_id)?'abc':'none'); ?></small></span>
                                                            </div>
                                                            <?php else: ?>
                                                            <div class="input-group-append">
                                                                <span class="mt-3 ml-2"> <small>Please Add Gender</small></span>
                                                            </div>
                                                        <?php endif; ?>                                                                
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>                                                    
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <?php if($user->husbands->isEmpty() == false): ?>
                                                <?php $__currentLoopData = $user->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-12 col-md-3">
                                                        <?php echo e(userPhoto($husband, ['class' => 'img-fluid rounded-circle border'])); ?>

                                                    </div>

                                                    <div class="col-12 col-md-9 text-center text-lg-left">
                                                        <div> <span class="text-muted"> <?php echo e(__('user.spouse')); ?></span> </div>
                                                        <div> <strong><?php echo e($husband->profileLink()); ?></strong> </div>
                                                        <?php if($husband->yob): ?>
                                                            <div> <small class="text-muted"><?php echo e(trans('user.dob')); ?> <?php echo e($husband->yob); ?></small> </div>
                                                        <?php endif; ?>
                                                    </div>                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            <?php else: ?>
                                                <div class="col-12 col-md-9 text-center text-lg-left">
                                                    <div> <strong><?php echo e(__('Hunband Record Not Found')); ?></strong> </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?> 
                                    <?php endif; ?>                                       
                                </div>
                            </div>
                            <?php echo $__env->make('users.partials.childs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                            
                        </div>
                    </div>
                </div>
            </div>
       
            <hr>
            <?php echo $__env->make('users.partials.siblings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>

 



<script>
$('#check_gender').click(function(){
alert('yesdfsdfsdf');
});
</script>    
<?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/partials/parent-spouse.blade.php ENDPATH**/ ?>