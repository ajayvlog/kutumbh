<?php
$marriages = $user->marriages()->with('husband', 'wife')
            ->withCount('childs')->get();
?>

    <div class="p-3 mt-3">
        <h5><?php echo e(__('Marriage Details')); ?></h5>
        <?php if($marriages->isEmpty()): ?>
            <i><?php echo e(__('Marriage were not recorded')); ?></i>
        <?php else: ?>
            <?php $__currentLoopData = $marriages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marriage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-md-1 col-2"></div>
                    <div class="col-md-11 col-10">
                        <div> <strong><?php echo e(__('Hunband')); ?> </strong> </div>
                        <div> <?php echo e($marriage->husband->profileLink()); ?></div><hr>

                        <div> <strong><?php echo e(trans('couple.wife')); ?> </strong> </div>
                        <div> <?php echo e($marriage->wife->profileLink()); ?></div><hr>

                        <div> <strong><?php echo e(trans('couple.marriage_date')); ?></strong> </div>
                        <div> <?php echo e($marriage->marriage_date ? $marriage->marriage_date : 'Date Not Available'); ?></div><hr>

                        <?php if($marriage->divorce_date): ?>
                            <div> <strong><?php echo e(trans('couple.divorce_date')); ?></strong> </div>
                            <div> <?php echo e($marriage->divorce_date); ?></div><hr>
                        <?php endif; ?>

                        <div> <strong><?php echo e(trans('couple.childs_count')); ?></strong> </div>
                        <div> <?php echo e($marriage->childs_count); ?></div>
                    </div>
                </div>
                <div class="panel-footer" style="margin-left: 29em;">
                    <?php echo e(link_to_route('couples.show', trans('couple.show'), [$marriage->id], ['class' => 'btn btn-primary btn-xs'])); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/partials/tabmarriages.blade.php ENDPATH**/ ?>