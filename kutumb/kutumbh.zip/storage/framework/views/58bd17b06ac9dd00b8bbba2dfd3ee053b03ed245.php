

<!doctype html>
<html lang="en">

<head>
    <title> Kutumbh </title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="keywords" content=" ">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" type="image/png" href="https://www.thehindutoday.com/site/images/favicon.png" />
    <link rel="stylesheet" href="<?php echo e(asset('css/override.css')); ?>">  <!-- override CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"/>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://www.thehindutoday.com/site/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.thehindutoday.com/site/css/style.css?v=1604207885">
    <link rel="stylesheet" href="https://www.thehindutoday.com/site/css/animate.css">
    <link rel="stylesheet" href="https://www.thehindutoday.com/site/css/custom.css?v=1604207885">
    <link rel="stylesheet" href="https://www.thehindutoday.com/vendor/font-awesome/css/font-awesome.min.css?v=1604207885">

    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap"
          rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Maven+Pro:400,500,700,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&display=swap"
          rel="stylesheet">
    <link rel="stylesheet" href="https://www.thehindutoday.com/plugins/scroller/style/jquery.jscrollpane.css?v=1604207885">
    
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    
    <style type="text/css">
        .row:before, .row:after {
            display: none !important;
        }
      .tooltip {
  transform: translate(-50%, -200%);
  display: none;
  position: absolute;
  color: #F0B015;
  background-color: #000;
  border: none;
  border-radius: 4px;
  padding: 15px 10px;
  z-index: 10;
  display: block;
  width: 100%;
  max-width: 200px;
  top: 0;
  left: 50%;
  text-align: center;
}
.tooltip:after {
  content: "";
  display: block;
  position: absolute;
  border-color: #000000 rgba(0, 0, 0, 0);
  border-style: solid;
  border-width: 15px 15px 0;
  bottom: -13px;
  left: 50%;
  transform: translate(-50%, 0);
  width: 0;
}
      
    </style>
    <script>
        (function () {
            var s = document.createElement('script');
            s.type = 'text/javascript';
            s.async = true;
            s.src = 'https://app.termly.io/embed.min.js';
            s.id = '9b0c0669-38f9-47d4-a1b0-e5b923e885e6';
            s.setAttribute("data-name", "termly-embed-banner");
            var x = document.getElementsByTagName('script')[0];
            x.parentNode.insertBefore(s, x);
        })();
        
      
    </script>
</head>

<body>
    <div class="wrapper">

        <style type="text/css">
            #left {
                position: sticky;
                top: 0%;
                height: 100vh;
            }
            .reglog-btns a {
                float: right;
            }
            .reglog-btns button{    
                color: #fff;
                height: 2.9em;
                width: 48%;
                border: none;
            }
            .head_bar{
                text-transform:none;
            }
        </style>
        <div class="container-fluid">
            <div class="toparea row">
                <div class="col-sm-3 leftsidebar  okfint">
                    <div class="sidebar_widget wow fadeInLeft" data-wow-delay="0.1s">
                        <div class="logodiv wow fadeInLeft tooltipLink"  title='Kutumbh Logo' data-tooltip="You disgust me. Meh!" >
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('images/kutumbh-logo.png')); ?>" class="img-fluid "
                                     alt="logo" >

                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                        </div>
                        <div class="sidebar_cntnt wow fadeInLeft">
                            <div class="sidebar-top border border-muted shadow-lg p-3 mb-5 bg-white rounded">
                                <h6 class="heading-medium"><?php echo e(trans('app.search_your_family')); ?></h6>
                                <?php if(request('q')): ?>
                                    <span>
                                        <small><?php echo trans('app.user_found', ['total' => $users->total(), 'keyword' => request('q')]); ?></small>
                                    </span>
                                <?php endif; ?>
                                
                                <?php echo e(Form::open(['method' => 'get','class' => ''])); ?>

                                
                                    
                                        <?php echo e(Form::text('q', request('q'), ['class' => 'form-control', 'placeholder' => trans('app.search_your_family_placeholder'), 'aria-label'=> trans('app.search_your_family_placeholder')])); ?>

                                    
                                    <div class="reglog-btns">
                                        <?php echo e(link_to_route('users.search', 'Reset', [], ['class' => 'logbtn'])); ?>

                                        <?php echo e(Form::button('Search', ['type' =>'submit','class' => 'logbtn'] )); ?> 
                                    </div>                                                                              
                                </div>
                                <?php echo e(Form::close()); ?>

                                <?php if(request('q')): ?>
                                    <br>
                                    
                                        <?php echo e($users->appends(Request::except('page'))->render()); ?>

                                        <?php $__currentLoopData = $users->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkedUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <?php $__currentLoopData = $chunkedUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                                <div class="panel panel-default shadow-lg p-3 mb-5  rounded">
                                                    <div class="panel-heading text-center">
                                                        <?php echo e(userPhoto($user, ['style' => 'width:100%;max-width:60px'])); ?>

                                                        
                                                        <?php if($user->age): ?>
                                                            <?php echo $user->age_string; ?>

                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="panel-body">
                                                        <h3 class="panel-title"><?php echo e($user->profileLink()); ?> (<?php echo e($user->gender); ?>)</h3>
                                                        <div><?php echo e(trans('user.nickname')); ?> : <b><?php echo e($user->nickname); ?></b></div>
                                                        <hr style="margin: 5px 0;">
                                                        <div><?php echo e(trans('user.father')); ?> : <b><?php echo e($user->father_id ? $user->father->name : ''); ?> </b></div>
                                                        <div><?php echo e(trans('user.mother')); ?> : <b><?php echo e($user->mother_id ? $user->mother->name : ''); ?> </b></div>
                                                    </div>
                                                    <div class="panel-footer">
                                                        <?php echo e(link_to_route('users.show', trans('app.show_profile'), [$user->id], ['class' => 'btn btn-default', 'style'=>'border: 2px solid; margin-left: 2em;'])); ?>

                                                        
                                                    </div>
                                                </div>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($users->appends(Request::except('page'))->render()); ?>

                                    
                                <?php endif; ?>
                                <hr>
                                <?php if(Auth::guard('web')->check()): ?>
                                    <div class="reglog-btns shadow-lg p-3 mb-5 bg-white rounded">
                                        <a class="logbtn" href="<?php echo e(route('profile')); ?>"><?php echo e(__('app.my_profile')); ?></a>
                                        <a class="regbtn" href="#" onclick="event.preventDefault();document.querySelector('#logout-form').submit();">
                                            Logout
                                        </a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                <?php else: ?>
                                <div class='shadow-lg p-3 mb-5  rounded'>
                                    <h6 class="tooltipLink" data-tooltip="You disgust me. Meh!" >Sign Up</h6>
                                    <form role="form" method="POST" action="<?php echo e(route('register')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-row ">
                                            
                                            <div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                <label for="inputName"><?php echo e(trans('user.name')); ?></label>
                                                <input id="name" type="text" class="form-control" name="name" placeholder="Name" value="<?php echo e(old('name')); ?>" required >
                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                                <label for="email"><?php echo e(trans('user.email')); ?></label>
                                                <input id="email" type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                                                <?php if($errors->has('email')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                                                         
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                <label for="password"><?php echo e(trans('auth.password')); ?></label>
                                                <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
                                                <?php if($errors->has('password')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="password-confirm"><?php echo e(trans('auth.password_confirmation')); ?></label>
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" required>
                                            </div>                            
                                        </div>
                                        <div class="reglog-btns">
                                            <button type="submit" class="regbtn">Register</button>
                                            <a class="logbtn" href="<?php echo e(route('login')); ?>">Login</a>
                                        </div>                                    
                                    </form>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-9 rightsection">
                    <div class="row td-fixed">
                        <div id="left" class="col-sm-12 col-md-6 col-xs-12 col-lg-6">
                            <div id="demo" class="carousel slide slidersec td-sticky" data-ride="carousel">
                                <!-- Indicators -->
                                <ul class="carousel-indicators">
                                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                                    
                                </ul>
                                <!-- The slideshow -->
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        
                                            <img src="<?php echo e(asset('images/Kutumbh.png')); ?>"
                                                 class="img-fluid slider_img" alt="Slide Image">
                                        
                                    </div>
                                    
                                </div>
                                <div class="navbtn">
                                    <a class="carousel-control-prev" href="#demo" role="button" data-slide="prev">
                                        <i class="fa fa-chevron-circle-left" aria-hidden="true"></i>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo" role="button" data-slide="next">
                                        <i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div id="right" class="col-sm-12 col-md-6 col-xs-12 col-lg-6" >
                            <!--new design put here-->
                            <div class="graphic-div text-sm-center text-md-left">
                                <div class="row td-fixed">
                                    <div class="col-12">
                                        <div class="font_20 head_bar">
                                            <h4>Welcome to Kutumbh.co.uk</h4>
                                            <h6><small>Preserve and cherish your family history.</small></h6>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-5 mb-3">
                                        <h4> Its quick and easy to start… </h4>
                                        <p><small>It is really easy and quick to register your information with us. Get started on building your own family tree.</small></p>
                                    </div>
                                    <div class="col-2 text-center rope-icon-holder">
                                        <span class="rope-icon rounded-circle"> <i class="fas fa-search"></i></span>
                                        <div class="divider-graphic-tree"> </div>
                                    </div>
                                    <div class="col-md-5 mb-5">
                                        <img class="img-fluid" src="images/graphic-family-tree.png">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-5 mb-3 order-sm-12">
                                        <h4> Safe and Secure </h4>
                                        <p><small> your family tree and sensitive information secure with us.</small></p>
                                    </div>
                                    <div class="col-2 text-center rope-icon-holder order-sm-2">
                                        <span class="rope-icon rounded-circle"> <i class="fas fa-leaf"></i></span>
                                        <div class="divider-graphic-tree"> </div>
                                    </div>
                                    <div class="col-md-5 mb-5 order-sm-1">
                                        <img class="img-fluid" src="images/graphic-family-tree2.png">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-5">
                                        <h4>Traditions, Culture and History</h4>
                                        <p><small> Means more to be of Indian origin than just our ethnicity. Our traditions are our heritage. Wherever we live, we have weaved our culture into a new global identity. Preserve your history for the younger generation. </small></p>
                                    </div>
                                    <div class="col-2 text-center rope-icon-holder">
                                        <span class="rope-icon rounded-circle"> <i class="fas fa-file-alt"></i></span>
                                        <div class="divider-graphic-tree"> </div>
                                    </div>
                                    <div class="col-md-5 mb-3">
                                        <img class="img-fluid" src="images/graphic-family-tree3.png">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-5 mb-3 order-sm-12">
                                        <h4> Why choose Kutumbh? </h4>
                                        <p><small> The home of Hindu history for global audience. </small></p>
                                        <ul>
                                            <li style="color: black">We help people of Indian diaspora to preserve and let them share their ancestry with their loved ones.</li>
                                            <li style="color: black">It is for us to pass our traditions and family history to the younger generation. We help you to pass down your valuable family history from you to your loved ones.</li>
                                            <li style="color: black">To stay connected with your homeland and your community.</li>
                                            <li style="color: black">Save your important information like gotra, ancestral village, janampatri etc. in a place with easy access. </li>
                                            <li style="color: black">Reminders for important information like marriage dates, death anniversaries in your family.</li>
                                            <li style="color: black">Feel supported – we at kutumbh are always ready to help you with any of your queries. Just drop us a message and we will be there to help you.</li>
                                        </ul>
                                    </div>
                                    <div class="col-2 text-center rope-icon-holder order-sm-2">
                                        <span class="rope-icon rounded-circle"> <i class="fas fa-leaf"></i></span>
                                        <div class="divider-graphic-tree"> </div>
                                    </div>
                                    <div class="col-md-5 mb-5 order-sm-1">
                                        <img class="img-fluid" src="images/graphic-family-tree2.png">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-5">
                                        
                                    </div>
                                    <div class="col-2 text-center rope-icon-holder">
                                        <span class="rope-icon rounded-circle"> <i class="fas fa-file-alt"></i></span>
                                        <div class="divider-graphic-tree"> </div>
                                    </div>
                                    <div class="col-md-5 mb-3">
                                        <img class="img-fluid" src="images/graphic-family-tree3.png">
                                    </div>
                                </div>


                                
                            </div>







                            <!--new design put here ends-->

                        </div>
                    </div>
                    <footer class="mainfooter" style="bottom:0;">
                        <div class="container-fluid">
                            <div class="footercontentdiv">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="footercontent">
                                            <ul>
                                                <li>
                                                    <a href="<?php echo url('/desclaimer');; ?>">Desclaimer</a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo url('/privacypolicy');; ?>">Privacy Policy</a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo url('/termsConditions');; ?>">Terms & Conditions</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </footer>
                    <div class="copyright">
                        <div class="container-fluid">
                            <div class="copyrightcontent">
                                <p>© 2020 <a href="http://kutumbh.co.uk" >Kutumbh </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://www.thehindutoday.com/site/js/jquery.min.js"></script>
    
    
     <script type="text/javascript">
  	$('.tooltipLink').hover(function () {
     var title = $(this).attr('data-tooltip');
     $(this).data('tipText', title);
     if(title == ''){}
     else{
        $('<p class="tooltip"></p>').fadeIn(200).text(title).appendTo('body');
     }
 }, function () {
     $(this).attr('data-tooltip', $(this).data('tipText'));
     $('.tooltip').fadeOut(200);
 }).mousemove(function (e) {
     var mousex = e.pageX;
     var mousey = e.pageY;
     $('.tooltip').css({
         top: mousey,
         left: mousex
     })
 });
  </script>
  
  
    <script src="https://www.thehindutoday.com/site/js/popper.min.js"></script>
    <script src="https://www.thehindutoday.com/site/js/bootstrap.min.js"></script>
    <script src="https://www.thehindutoday.com/site/js/wow.min.js"></script>
    
    <script src="https://www.thehindutoday.com/site/js/custom.js?v=1604207885"></script>
    <style type="text/css">
        #flux {
            width: 200px;
            height: 150px;
            overflow: auto;
        }
    </style>
    <script src="https://www.thehindutoday.com/plugins/scroller/script/jquery.jscrollpane.js"></script>
    <script src="https://www.thehindutoday.com/plugins/scroller/script/jquery.mousewheel.js"></script>
    <script type="text/javascript">
        $(function () {
            var pane = $('.scroll-pane');
            pane.jScrollPane(
                {
                    showArrows: true,
                    animateScroll: true,
                    arrowScrollOnHover: false,
                    hijackInternalLinks: true,
                    mouseWheelSpeed: 500
                }
            );
            var api = pane.data('jsp');

            $('#scroll-to').on(
                'click',
                function () {

                    api.scrollTo(parseInt(220), parseInt(220));
                    return false;
                }
            );
        });
    </script>
    <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5d4150fa3d33218b"></script>  
   
  
</body>
</html><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/search.blade.php ENDPATH**/ ?>