
<div title='User Photo' class="col-3 col-md-1 border border-muted p-3 mb-5 rounded jpbox2 bg-white tooltipLink" data-tooltip="hover tooltip" >
    <?php echo e(userPhoto($user, ['class' => 'img-fluid rounded-circle border'])); ?>

</div>
<div class="col-md-6 col-6 ">
    <span> <strong title='User'><?php echo e($user->name); ?></strong> </span> <span><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $user)): ?> <a class="text-dark" href="<?php echo e(route('users.edit',[$user->id])); ?>"><i class="fas fa-pen"></i> </a> <?php endif; ?></span>

   <div> <small><?php if($user->yob): ?><?php echo e(trans('user.dob')); ?> <?php echo e($user->yob); ?>, <?php endif; ?> <?php echo nl2br($user->address); ?></small> </div>
   <div class="dropdown">
       <a href="#!" class="border dropdown-toggle pl-2 pr-2 text-dark rounded" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           <small> View on tree</small>
       </a>
       <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <?php echo e(link_to_route('users.tree', trans('app.show_family_tree'), [$user->id], ['class' => 'dropdown-item p-0 pl-2'])); ?>

            <a href="<?php echo e(route('users.pedigreetree', [$user->id] )); ?>" class="dropdown-item p-0 pl-2"><?php echo e(__('Padigree View')); ?></a>
        </div>
    </div>
</div>
<div class="col-md-5 col-3 text-md-right">
    <?php if($user->yob): ?>
        <strong>
            <?php echo e($user->yob); ?>-<?php echo e($user->yod ? 'Expired':'Living'); ?>

        </strong>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/partials/profile.blade.php ENDPATH**/ ?>