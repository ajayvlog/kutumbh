<?php
$marriages = $user->marriages()->pluck('marriage_date')->first();
?>
<div class="col-md-6 ">
    <div class="shadow p-3 mb-5 bg-white rounded">
       
        <h5> Timeline</h5>
        <?php if($user->dob): ?>
            <div class="row">
                <div class="col-md-1 col-2">  <h2 class="mt-2"><i class="fas fa-baby"></i></h2> </div>
                <div class="col-md-11 col-10">
                    <div> <strong><?php echo e(__('Born On')); ?> <?php echo e($user->dob); ?></strong> </div>
                    <div> <?php echo e($user->name); ?> was born on <?php echo e($user->dob); ?> in <?php echo e($user->address); ?>.</div>
                </div>
            </div><hr>
        <?php endif; ?>
        <?php if($marriages): ?>
            <?php if($user->gender_id == 1): ?>
                <div class="row">
                    <div class="col-md-1 col-2">  <h2 class="mt-2"><i class="fas fa-heart"></i></h2> </div>
                    <div class="col-md-11 col-10">
                        <div> <strong><?php echo e(__('Marriage ')); ?> <?php echo e($marriages ? $marriages : ''); ?></strong> </div>
                        <div> <?php echo e($user->name); ?> was Married to
                            <?php if($user->wifes->isEmpty() == false): ?>
                                <?php $__currentLoopData = $user->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($wife->profileLink()); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            on <?php echo e($marriages ? $marriages : '"Date Not Available"'); ?>

                        </div>                  
                    </div>
                </div><hr>
            <?php else: ?>
                <div class="row">
                    <div class="col-md-1 col-2">  <h2 class="mt-2"><i class="fas fa-heart"></i></h2> </div>
                    <div class="col-md-11 col-10">
                        <div> <strong><?php echo e(__('Marriage ')); ?> <?php echo e($marriages ? $marriages : ''); ?></strong> </div>
                        <div> <?php echo e($user->name); ?> was Married to
                            <?php if($user->husbands->isEmpty() == false): ?>
                                <?php $__currentLoopData = $user->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($husband->profileLink()); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            on <?php echo e($marriages ? $marriages : '"Date Not Available"'); ?>

                        </div>                  
                    </div>
                </div> <hr>           
            <?php endif; ?>
        <?php endif; ?>
        <?php if( $user->childs): ?>
            <?php $__empty_1 = true; $__currentLoopData = $user->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="row">
                    <div class="col-md-1 col-2">  <h2 class="mt-2"><i class="fas fa-child"></i></h2> </div>
                    <div class="col-md-11 col-10">
                        <div> <strong><?php echo e(__('Having ')); ?> <?php echo e($child->gender == 'F' ? __('Daughter') : __('Son')); ?></strong> </div>
                        <div> <?php echo e($user->name); ?> having <?php echo e($child->gender == 'F' ? __('Daughter') : __('Son')); ?>

                              <?php echo e($child->profileLink()); ?>

                            on <?php echo e($child->dob ? $child->dob : '"Date Not Available"'); ?>

                        </div>                  
                    </div>
                </div><hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if($user->medias): ?>
            <?php $__currentLoopData = $user->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-md-1 col-2">  <h2 class="mt-2"><i class="<?php echo e($media->file_path ? 'fas fa-image':'fas fa-video'); ?>"></i></h2> </div>
                <div class="col-md-11 col-10">
                    <?php if($media->title): ?>
                    <div> <strong><?php echo e(__('Shared a Memory Moment with Title ')); ?><i><?php echo e('"'.$media->title.'"'); ?></i></strong> </div><?php endif; ?>
                    <div> 
                        <?php if($media->file_path): ?>
                            <img src="<?php echo e(asset('storage/'.$media->file_path)); ?>"><br>
                        <?php endif; ?>
                        <?php if($media->video_url): ?>
                            <?php echo e($media->video_url); ?><br>
                        <?php endif; ?>
                        <?php echo e(__('Description: ')); ?><i><?php echo e('"'.$media->description.'"'); ?></i><br>
                        <?php echo e(__(' Location: ')); ?><i><?php echo e('"'. $media->location.'"'); ?></i><br>
                        <?php echo e(__(' Dated: ')); ?> <?php echo e($media->date ? $media->date : '"Date Not Available"'); ?>

                    </div>                  
                </div>
            </div><hr>                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if($user->notes): ?>
            <?php $__currentLoopData = $user->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-md-1 col-2">  <h2 class="mt-2"><i class="fas fa-file"></i></h2> </div>
                <div class="col-md-11 col-10">
                    <div> <strong><?php echo e($user->name); ?> <?php echo e(__('Shared a Notes')); ?> </strong> </div>
                    <div> 
                        <?php echo e(__('Note: ')); ?><i><?php echo e('"'.$note->notes.'"'); ?></i>
                    </div>                  
                </div>
            </div><hr>                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/partials/profile-timeline.blade.php ENDPATH**/ ?>