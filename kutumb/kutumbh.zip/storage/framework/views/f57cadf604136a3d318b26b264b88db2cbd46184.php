<!-- Header-->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"> <img class="logo" src="<?php echo e(asset('images/kutumbh-logo.png')); ?>"> </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav ml-auto mt-2">

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('users.search')); ?>"><?php echo e(__('app.search_your_family')); ?></a>
                    </li>
                    
                    <!-- Authentication Links -->
                    <?php if(Auth::guard('web')->check()): ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link " href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::guard('web')->user()->name); ?><i class="fas fa-angle-down"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                
                                <a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><?php echo e(__('app.my_profile')); ?></a>
                                <a class="dropdown-item" href="<?php echo e(route('password.change')); ?>"><?php echo e(__('auth.change_password')); ?></a>
                                <a class="dropdown-item" href="#" onclick="event.preventDefault();document.querySelector('#logout-form').submit();">
                                    Logout
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn-register" href="<?php echo e(route('register')); ?>">Create Account</a>
                        </li>
                    <?php endif; ?>
                    
                    

                </ul>
            </div>
        </div>
    </nav>
<!-- Header ends-->
<?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/layouts/partials/nav.blade.php ENDPATH**/ ?>