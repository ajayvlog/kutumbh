<?php $__env->startSection('subtitle', trans('app.family_tree')); ?>



<?php $__env->startSection('user-content'); ?>

<?php
$childsTotal = 0;
$grandChildsTotal = 0;
$ggTotal = 0;
$ggcTotal = 0;
$ggccTotal = 0;

$parentsTotal = 0;
$grandParentsTotal = 0;
$ggPTotal = 0;
$ggPcTotal = 0;
$ggccPTotal = 0;
?>
<div class="row">
<div class="container-fluid mt-2">
    
    <div class="row">
        <div class="col-12 mt-2">
            <div class="my-custom-scrollbar my-custom-scrollbar-primary">
                <div class="tree">
                    <?php if($parentsCount = $user->parents->count()): ?>
                        <?php $parentsTotal += $parentsCount ?>
                        <?php $__currentLoopData = $user->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($grandsPCount = $parent->parents->count()): ?>
                                <?php $grandParentsTotal += $grandsPCount ?>
                                <?php $__currentLoopData = $parent->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($ggPCount = $grandP->parents->count()): ?>
                                        <?php $ggPTotal += $ggPCount ?>
                                        <?php $__currentLoopData = $grandP->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ggPcCount = $ggP->parents->count()): ?>
                                                <?php $ggPcTotal += $ggPcCount ?>
                                                <?php $__currentLoopData = $ggP->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggcP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($ggccPCount = $ggcP->parents->count()): ?>
                                                        <?php $ggccPTotal += $ggccPCount ?>
                                                        <?php $__currentLoopData = $ggcP->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggccP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <ul>
                                                            <li>
                                                                <div>
                                                                    <span class="male">
                                                                        <a href="<?php echo e(route('users.tree',[$ggccP->id])); ?>" title="<?php echo e($ggccP->name.' ('.$ggccP->gender.')'); ?>">
                                                                            <span class="img-gender"><?php echo e(userPhoto($ggccP, [])); ?></span>
                                                                            <span class="name"> <?php echo e($ggccP->name); ?> </span>
                                                                            <span class="gender"><?php echo e($ggccP->gender); ?></span>
                                                                        </a>
                                                                    </span>
                                                                    <?php if($ggccP->gender_id == 1): ?>
                                                                        <?php if($ggccP->wifes->isEmpty() == false): ?>
                                                                            <?php $__currentLoopData = $ggccP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <span class="female">
                                                                                    <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                        <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                        <span class="name"><?php echo e($wife->name); ?></span>
                                                                                        <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                    </a>
                                                                                </span>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <?php if($ggccP->husbands->isEmpty() == false): ?>
                                                                            <?php $__currentLoopData = $ggccP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <span class="female">
                                                                                    <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                        <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                        <span class="name"><?php echo e($husband->name); ?></span>
                                                                                        <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                    </a>
                                                                                </span>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    <ul>
                                                        <li>
                                                            <div>
                                                                <span class="male">
                                                                    <a href="<?php echo e(route('users.tree',[$ggcP->id])); ?>" title="<?php echo e($ggcP->name.' ('.$ggcP->gender.')'); ?>">
                                                                        <span class="img-gender"><?php echo e(userPhoto($ggcP, [])); ?></span>
                                                                        <span class="name"> <?php echo e($ggcP->name); ?> </span>
                                                                        <span class="gender"><?php echo e($ggcP->gender); ?></span>
                                                                    </a>
                                                                </span>
                                                                <?php if($ggcP->gender_id == 1): ?>
                                                                    <?php if($ggcP->wifes->isEmpty() == false): ?>
                                                                        <?php $__currentLoopData = $ggcP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <span class="female">
                                                                                <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                    <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                    <span class="name"><?php echo e($wife->name); ?></span>
                                                                                    <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                </a>
                                                                            </span>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <?php if($ggcP->husbands->isEmpty() == false): ?>
                                                                        <?php $__currentLoopData = $ggcP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <span class="female">
                                                                                <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                    <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                    <span class="name"><?php echo e($husband->name); ?></span>
                                                                                    <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                </a>
                                                                            </span>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <ul>
                                                    <li>
                                                        <div>
                                                            <span class="male">
                                                                <a href="<?php echo e(route('users.tree',[$ggP->id])); ?>" title="<?php echo e($ggP->name.' ('.$ggP->gender.')'); ?>">
                                                                    <span class="img-gender"><?php echo e(userPhoto($ggP, [])); ?></span>
                                                                    <span class="name"> <?php echo e($ggP->name); ?> </span>
                                                                    <span class="gender"><?php echo e($ggP->gender); ?></span>
                                                                </a>
                                                            </span>
                                                            <?php if($ggP->gender_id == 1): ?>
                                                                <?php if($ggP->wifes->isEmpty() == false): ?>
                                                                    <?php $__currentLoopData = $ggP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <span class="female">
                                                                            <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                            </a>
                                                                        </span>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($ggP->husbands->isEmpty() == false): ?>
                                                                    <?php $__currentLoopData = $ggP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <span class="female">
                                                                            <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                            </a>
                                                                        </span>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <ul>
                                                <li>
                                                    <div>
                                                        <span class="male">
                                                            <a href="<?php echo e(route('users.tree',[$grandP->id])); ?>" title="<?php echo e($grandP->name.' ('.$grandP->gender.')'); ?>">
                                                                <span class="img-gender"><?php echo e(userPhoto($grandP, [])); ?></span>
                                                                <span class="name"> <?php echo e($grandP->name); ?> </span>
                                                                <span class="gender"><?php echo e($grandP->gender); ?></span>
                                                            </a>
                                                        </span>
                                                        <?php if($grandP->gender_id == 1): ?>
                                                            <?php if($grandP->wifes->isEmpty() == false): ?>
                                                                <?php $__currentLoopData = $grandP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <span class="female">
                                                                        <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                            <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                            <span class="name"><?php echo e($wife->name); ?></span>
                                                                            <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                        </a>
                                                                    </span>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($grandP->husbands->isEmpty() == false): ?>
                                                                <?php $__currentLoopData = $grandP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <span class="female">
                                                                        <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                            <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                            <span class="name"><?php echo e($husband->name); ?></span>
                                                                            <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                        </a>
                                                                    </span>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <ul>
                                            <li>
                                                <div>
                                                    <span class="male">
                                                        <a href="<?php echo e(route('users.tree',[$parent->id])); ?>" title="<?php echo e($parent->name.' ('.$parent->gender.')'); ?>">
                                                            <span class="img-gender"><?php echo e(userPhoto($parent, [])); ?></span>
                                                            <span class="name"> <?php echo e($parent->name); ?> </span>
                                                            <span class="gender"><?php echo e($parent->gender); ?></span>
                                                        </a>
                                                    </span>
                                                    <?php if($parent->gender_id == 1): ?>
                                                        <?php if($parent->wifes->isEmpty() == false): ?>
                                                            <?php $__currentLoopData = $parent->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="female">
                                                                    <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                        <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                        <span class="name"><?php echo e($wife->name); ?></span>
                                                                        <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                    </a>
                                                                </span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php if($parent->husbands->isEmpty() == false): ?>
                                                            <?php $__currentLoopData = $parent->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="female">
                                                                    <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                        <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                        <span class="name"><?php echo e($husband->name); ?></span>
                                                                        <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                    </a>
                                                                </span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <ul>
                                        <li>
                                            <div>
                                                 <span class="male">
                                                    <a href="<?php echo e(route('users.tree',[$user->id])); ?>" title="<?php echo e($user->name.' ('.$user->gender.')'); ?>">
                                                        <span class="img-gender"><?php echo e(userPhoto($user, [])); ?></span>
                                                        <span class="name"> <?php echo e($user->name); ?> </span>
                                                        <span class="gender"><?php echo e($user->gender); ?></span>
                                                    </a>
                                                </span>
                                                <?php if($user->gender_id == 1): ?>
                                                    <?php if($user->wifes->isEmpty() == false): ?>
                                                        <?php $__currentLoopData = $user->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="female">
                                                                <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                    <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                    <span class="name"><?php echo e($wife->name); ?></span>
                                                                    <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                </a>
                                                            </span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($user->husbands->isEmpty() == false): ?>
                                                        <?php $__currentLoopData = $user->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="female">
                                                                <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                    <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                    <span class="name"><?php echo e($husband->name); ?></span>
                                                                    <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                </a>
                                                            </span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                            <?php if($childsCount = $user->childs->count()): ?>
                                                <?php $childsTotal += $childsCount ?>
                                                <ul>
                                                <?php $__currentLoopData = $user->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <div>
                                                             <span class="male">
                                                                <a href="<?php echo e(route('users.tree',[$child->id])); ?>" title="<?php echo e($child->name.' ('.$child->gender.')'); ?>">
                                                                    <span class="img-gender"><?php echo e(userPhoto($child, [])); ?></span>
                                                                    <span class="name"> <?php echo e($child->name); ?> </span>
                                                                    <span class="gender"><?php echo e($child->gender); ?></span>
                                                                </a>
                                                            </span>
                                                            <?php if($child->gender_id == 1): ?>
                                                                <?php if($child->wifes->isEmpty() == false): ?>
                                                                    <?php $__currentLoopData = $child->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <span class="female">
                                                                            <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                            </a>
                                                                        </span>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($child->husbands->isEmpty() == false): ?>
                                                                    <?php $__currentLoopData = $child->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <span class="female">
                                                                            <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                            </a>
                                                                        </span>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </div>
                                                        <?php if($grandsCount = $child->childs->count()): ?>
                                                            <?php $grandChildsTotal += $grandsCount ?>
                                                            <ul>
                                                                <?php $__currentLoopData = $child->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li> 
                                                                        <div>
                                                                            <span class="male">
                                                                                <a href="<?php echo e(route('users.tree',[$grand->id])); ?>" title="<?php echo e($grand->name.' ('.$grand->gender.')'); ?>">
                                                                                    <span class="img-gender"><?php echo e(userPhoto($grand, [])); ?></span>
                                                                                    <span class="name"> <?php echo e($grand->name); ?> </span>
                                                                                    <span class="gender"><?php echo e($grand->gender); ?></span>
                                                                                </a>
                                                                            </span>
                                                                            <?php if($grand->gender_id == 1): ?>
                                                                                <?php if($grand->wifes->isEmpty() == false): ?>
                                                                                    <?php $__currentLoopData = $grand->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <span class="female">
                                                                                            <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                            </a>
                                                                                        </span>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php endif; ?>
                                                                            <?php else: ?>
                                                                                <?php if($grand->husbands->isEmpty() == false): ?>
                                                                                    <?php $__currentLoopData = $grand->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <span class="female">
                                                                                            <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                            </a>
                                                                                        </span>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php endif; ?>
                                                                            <?php endif; ?>
                                                                        </div> 
                                                                        <?php if($ggCount = $grand->childs->count()): ?>
                                                                            <?php $ggTotal += $ggCount ?>
                                                                            <ul>
                                                                                <?php $__currentLoopData = $grand->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <li>
                                                                                        <div>
                                                                                            <span class="male">
                                                                                                <a href="<?php echo e(route('users.tree',[$gg->id])); ?>" title="<?php echo e($gg->name.' ('.$gg->gender.')'); ?>">
                                                                                                    <span class="img-gender"><?php echo e(userPhoto($gg, [])); ?></span>
                                                                                                    <span class="name"> <?php echo e($gg->name); ?> </span>
                                                                                                    <span class="gender"><?php echo e($gg->gender); ?></span>
                                                                                                </a>
                                                                                            </span>
                                                                                            <?php if($gg->gender_id == 1): ?>
                                                                                                <?php if($gg->wifes->isEmpty() == false): ?>
                                                                                                    <?php $__currentLoopData = $gg->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                        <span class="female">
                                                                                                            <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                                            </a>
                                                                                                        </span>
                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                <?php endif; ?>
                                                                                            <?php else: ?>
                                                                                                <?php if($gg->husbands->isEmpty() == false): ?>
                                                                                                    <?php $__currentLoopData = $gg->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                        <span class="female">
                                                                                                            <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                                            </a>
                                                                                                        </span>
                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                <?php endif; ?>
                                                                                            <?php endif; ?>
                                                                                        </div>
                                                                                        <?php if($ggcCount = $gg->childs->count()): ?>
                                                                                            <?php $ggcTotal += $ggcCount ?>
                                                                                            <ul>
                                                                                                <?php $__currentLoopData = $gg->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <li>
                                                                                                        <div>
                                                                                                            <span class="male">
                                                                                                                <a href="<?php echo e(route('users.tree',[$ggc->id])); ?>" title="<?php echo e($ggc->name.' ('.$ggc->gender.')'); ?>">
                                                                                                                    <span class="img-gender"><?php echo e(userPhoto($ggc, [])); ?></span>
                                                                                                                    <span class="name"> <?php echo e($ggc->name); ?> </span>
                                                                                                                    <span class="gender"><?php echo e($ggc->gender); ?></span>
                                                                                                                </a>
                                                                                                            </span>
                                                                                                            <?php if($ggc->gender_id == 1): ?>
                                                                                                                <?php if($ggc->wifes->isEmpty() == false): ?>
                                                                                                                    <?php $__currentLoopData = $ggc->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <span class="female">
                                                                                                                            <a href="<?php echo e(route('users.tree',[$wife->id])); ?>" title="<?php echo e($wife->name.' ('.$wife->gender.')'); ?>">                                            
                                                                                                                                <span class="img-gender"><?php echo e(userPhoto($wife, [])); ?></span>
                                                                                                                                <span class="name"><?php echo e($wife->name); ?></span>
                                                                                                                                <span class="gender"><?php echo e($wife->gender); ?></span>
                                                                                                                            </a>
                                                                                                                        </span>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                <?php endif; ?>
                                                                                                            <?php else: ?>
                                                                                                                <?php if($ggc->husbands->isEmpty() == false): ?>
                                                                                                                    <?php $__currentLoopData = $ggc->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <span class="female">
                                                                                                                            <a href="<?php echo e(route('users.tree',[$husband->id])); ?>" title="<?php echo e($husband->name.' ('.$husband->gender.')'); ?>">
                                                                                                                                <span class="img-gender"><?php echo e(userPhoto($husband, [])); ?></span>
                                                                                                                                <span class="name"><?php echo e($husband->name); ?></span>
                                                                                                                                <span class="gender"><?php echo e($husband->gender); ?></span>
                                                                                                                            </a>
                                                                                                                        </span>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                <?php endif; ?>
                                                                                                            <?php endif; ?>
                                                                                                        </div>
                                                                                                    </li>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            </ul>
                                                                                        <?php endif; ?>
                                                                                    </li>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </ul>
                                                                        <?php endif; ?>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </li>
</ul>
</li>
</ul>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('treeflex_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/treeflex2.css')); ?>">
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.user-profile-wide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/tree.blade.php ENDPATH**/ ?>