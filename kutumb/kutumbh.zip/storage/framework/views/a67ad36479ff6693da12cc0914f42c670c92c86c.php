

    <div class="row">
        <div class="col-12 mb-3">
            <a class="add-custom-icon text-dark" data-toggle="collapse" href="#collapseSiblings" role="button" aria-expanded="false" aria-controls="collapseSiblings">
                <strong><?php echo e(trans('user.siblings')); ?></strong>
            </a>
            <span class="text-muted">(<?php echo e($user->siblings()->count()); ?>)</span>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="collapse show" id="collapseSiblings">
                <div class="row">
                    <?php $__currentLoopData = $user->siblings(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sibling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12">
                            <div class="input-group">
                                <div class="col-12 col-md-3">
                                    <?php echo e(userPhoto($sibling, ['class' => 'img-fluid rounded-circle border'])); ?>

                                </div>

                                <div class="col-12 col-md-9 text-center text-lg-left">
                                    <div> <span class="text-muted"> <?php echo e($sibling->gender == 'F' ? __('Sister') : __('Brother')); ?></span> </div>
                                    <div> <strong><?php echo e($sibling->profileLink()); ?> (<?php echo e($sibling->gender); ?>)</strong> </div>
                                    <?php if($sibling->yob): ?>
                                        <div> <small class="text-muted"><?php echo e(trans('user.dob')); ?> <?php echo e($sibling->yob); ?></small> </div>
                                    <?php endif; ?>
                                </div>                                 
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/partials/siblings.blade.php ENDPATH**/ ?>