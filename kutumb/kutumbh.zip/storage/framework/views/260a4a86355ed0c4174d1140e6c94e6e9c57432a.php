<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-3">
        <div class="mb-2  text-dark col-12 border pt-2">
            <?php echo $__env->yieldContent('user-content'); ?>
            <?php echo $__env->make('users.partials.action-buttons', ['user' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-overview" role="tabpanel" aria-labelledby="pills-overview-tab">
                        <div class="row">
                            <?php echo $__env->make('users.partials.profile-timeline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                            <?php echo $__env->make('users.partials.parent-spouse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-chart" role="tabpanel" aria-labelledby="pills-chart-tab">
                        <div class="mb-2  text-dark col-12 border pt-2">
                            <?php echo $__env->make('users.partials.tabchart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-tree" role="tabpanel" aria-labelledby="pills-tree-tab">
                        <div class="mb-2  text-dark col-12 border pt-2">
                            <?php echo $__env->make('users.partials.tabtree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         </div>
                    </div>
                    <div class="tab-pane fade" id="pills-marriages" role="tabpanel" aria-labelledby="pills-marriages-tab">
                        <div class="mb-2  text-dark col-12 border pt-2">
                            <?php echo $__env->make('users.partials.tabmarriages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         </div>    
                    </div>
                    <div class="tab-pane fade" id="media-post" role="tabpanel" aria-labelledby="media-post-tab">
                        <div class="mb-2  text-dark col-12 border pt-2">
                            <?php echo $__env->make('users.partials.mediapost', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         </div>    
                    </div>
                    <div class="tab-pane fade" id="pills-notes" role="tabpanel" aria-labelledby="pills-notes-tab">
                        <div class="mb-2  text-dark col-12 border pt-2">
                            <?php echo $__env->make('users.partials.notes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         </div>    
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/layouts/user-profile.blade.php ENDPATH**/ ?>