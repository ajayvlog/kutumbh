<?php $__env->startSection('subtitle', trans('app.family_tree')); ?>



<?php $__env->startSection('user-content'); ?>

<?php
$childsTotal = 0;
$grandChildsTotal = 0;
$ggTotal = 0;
$ggcTotal = 0;
$ggccTotal = 0;

$parentsTotal = 0;
$grandParentsTotal = 0;
$ggPTotal = 0;
$ggPcTotal = 0;
$ggccPTotal = 0;
?>

<div id="wrapper">
    
    <span class="label"><?php echo e(link_to_route('users.tree', $user->name.' ('.$user->gender.')', [$user->id], ['title' => $user->name.' ('.$user->gender.')'])); ?></span>

    <?php if($parentsCount = $user->parents->count()): ?>
        <?php //echo $user->parents->count();
        //echo "<pre>";print_r($user->parents); echo "</pre>". die();

        $parentsTotal += $parentsCount ?>
        <div class="branch lv1">
            <?php $__currentLoopData = $user->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="entry <?php echo e($parentsCount == 1 ? 'sole' : ''); ?>">
                <span class="label"><?php echo e(link_to_route('users.tree', $parent->name.' ('.$parent->gender.')', [$parent->id], ['title' => $parent->name.' ('.$parent->gender.')'])); ?></span>
                <?php if($grandsPCount = $parent->parents->count()): ?>
                <?php $grandParentsTotal += $grandsPCount ?>
                <div class="branch lv2">
                    <?php $__currentLoopData = $parent->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="entry <?php echo e($grandsPCount == 1 ? 'sole' : ''); ?>">
                        <span class="label"><?php echo e(link_to_route('users.tree', $grandP->name.' ('.$grandP->gender.')', [$grandP->id], ['title' => $grandP->name.' ('.$grandP->gender.')'])); ?></span>
                        <?php if($ggPCount = $grandP->parents->count()): ?>
                        <?php $ggPTotal += $ggPCount ?>
                        <div class="branch lv3">
                            <?php $__currentLoopData = $grandP->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="entry <?php echo e($ggPCount == 1 ? 'sole' : ''); ?>">
                                <span class="label"><?php echo e(link_to_route('users.tree', $ggP->name.' ('.$ggP->gender.')', [$ggP->id], ['title' => $ggP->name.' ('.$ggP->gender.')'])); ?></span>
                                <?php if($ggPcCount = $ggP->parents->count()): ?>
                                <?php $ggPcTotal += $ggPcCount ?>
                                <div class="branch lv4">
                                    <?php $__currentLoopData = $ggP->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggcP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="entry <?php echo e($ggPcCount == 1 ? 'sole' : ''); ?>">
                                        <span class="label"><?php echo e(link_to_route('users.tree', $ggcP->name.' ('.$ggcP->gender.')', [$ggcP->id], ['title' => $ggcP->name.' ('.$ggcP->gender.')'])); ?></span>
                                        <?php if($ggccPCount = $ggcP->parents->count()): ?>
                                        <?php $ggccPTotal += $ggccPCount ?>
                                        <div class="branch lv5">
                                            <?php $__currentLoopData = $ggcP->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ggccP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="entry <?php echo e($ggccPCount == 1 ? 'sole' : ''); ?>">
                                                <span class="label"><?php echo e(link_to_route('users.tree', $ggccP->name.' ('.$ggccP->gender.')', [$ggccP->id], ['title' => $ggccP->name.' ('.$ggccP->gender.')'])); ?></span>
                                            </div>
                                            <?php if($ggccP->gender_id == 1): ?>
                                                <?php if($ggccP->wifes->isEmpty() == false): ?>
                                                    <?php $__currentLoopData = $ggccP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="entry sole">
                                                        <span class="label"><?php echo e(link_to_route('users.tree', $wife->name.' ('.$wife->gender.')', [$wife->id], ['title' => $wife->name.' ('.$wife->gender.')'])); ?></span>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if($ggccP->husbands->isEmpty() == false): ?>
                                                    <?php $__currentLoopData = $ggccP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="label"><?php echo e(link_to_route('users.tree', $husband->name.' ('.$husband->gender.')', [$husband->id], ['title' => $husband->name.' ('.$husband->gender.')'])); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($ggcP->gender_id == 1): ?>
                                        <?php if($ggcP->wifes->isEmpty() == false): ?>
                                            <?php $__currentLoopData = $ggcP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="entry sole">
                                                <span class="label"><?php echo e(link_to_route('users.tree', $wife->name.' ('.$wife->gender.')', [$wife->id], ['title' => $wife->name.' ('.$wife->gender.')'])); ?></span>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($ggcP->husbands->isEmpty() == false): ?>
                                            <?php $__currentLoopData = $ggcP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="label"><?php echo e(link_to_route('users.tree', $husband->name.' ('.$husband->gender.')', [$husband->id], ['title' => $husband->name.' ('.$husband->gender.')'])); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php if($ggP->gender_id == 1): ?>
                                <?php if($ggP->wifes->isEmpty() == false): ?>
                                    <?php $__currentLoopData = $ggP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="entry sole">
                                        <span class="label"><?php echo e(link_to_route('users.tree', $wife->name.' ('.$wife->gender.')', [$wife->id], ['title' => $wife->name.' ('.$wife->gender.')'])); ?></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($ggP->husbands->isEmpty() == false): ?>
                                    <?php $__currentLoopData = $ggP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="label"><?php echo e(link_to_route('users.tree', $husband->name.' ('.$husband->gender.')', [$husband->id], ['title' => $husband->name.' ('.$husband->gender.')'])); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if($grandP->gender_id == 1): ?>
                        <?php if($grandP->wifes->isEmpty() == false): ?>
                            <?php $__currentLoopData = $grandP->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="entry sole">
                                <span class="label"><?php echo e(link_to_route('users.tree', $wife->name.' ('.$wife->gender.')', [$wife->id], ['title' => $wife->name.' ('.$wife->gender.')'])); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($grandP->husbands->isEmpty() == false): ?>
                            <?php $__currentLoopData = $grandP->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label"><?php echo e(link_to_route('users.tree', $husband->name.' ('.$husband->gender.')', [$husband->id], ['title' => $husband->name.' ('.$husband->gender.')'])); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
            <?php if($parent->gender_id == 1): ?>
                    <?php if($parent->wifes->isEmpty() == false): ?>
                        <?php $__currentLoopData = $parent->wifes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wife): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="entry sole">
                            <span class="label"><?php echo e(link_to_route('users.tree', $wife->name.' ('.$wife->gender.')', [$wife->id], ['title' => $wife->name.' ('.$wife->gender.')'])); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if($parent->husbands->isEmpty() == false): ?>
                        <?php $__currentLoopData = $parent->husbands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $husband): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="label"><?php echo e(link_to_route('users.tree', $husband->name.' ('.$husband->gender.')', [$husband->id], ['title' => $husband->name.' ('.$husband->gender.')'])); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <?php endif; ?>
    </div>
    
</div>
<div class="container">
<hr>
<div class="row">
    <div class="col-md-1">&nbsp;</div>
    <?php if($childsTotal): ?>
    <div class="col-md-1 text-right"><?php echo e(trans('app.child_count')); ?></div>
    <div class="col-md-1 text-left"><strong style="font-size:30px"><?php echo e($childsTotal); ?></strong></div>
    <?php endif; ?>
    <?php if($grandChildsTotal): ?>
    <div class="col-md-1 text-right"><?php echo e(trans('app.grand_child_count')); ?></div>
    <div class="col-md-1 text-left"><strong style="font-size:30px"><?php echo e($grandChildsTotal); ?></strong></div>
    <?php endif; ?>
    <?php if($ggTotal): ?>
    <div class="col-md-1 text-right"><?php echo e(trans('app.great_grand_child_count')); ?></div>
    <div class="col-md-1 text-left"><strong style="font-size:30px"><?php echo e($ggTotal); ?></strong></div>
    <?php endif; ?>  
    <?php if($ggcTotal): ?>
    <div class="col-md-1 text-right"><?php echo e(trans('app.great_great_grand_child_count')); ?></div>
    <div class="col-md-1 text-left"><strong style="font-size:30px"><?php echo e($ggcTotal); ?></strong></div>
    <?php endif; ?>
    <?php if($ggccTotal): ?>
    <div class="col-md-1 text-right"><?php echo e(trans('app.great_great_great_grand_child_count')); ?></div>
    <div class="col-md-1 text-left"><strong style="font-size:30px"><?php echo e($ggccTotal); ?></strong></div>
    <?php endif; ?>
    <div class="col-md-1">&nbsp;</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('treeflex_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/tree.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-profile-wide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/users/pedigreetree.blade.php ENDPATH**/ ?>