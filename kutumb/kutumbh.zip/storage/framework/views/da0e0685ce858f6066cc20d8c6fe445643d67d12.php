<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row">
        <div class="col-12"> <h3>Create Account</h3></div>
        <div class="col-md-6">
            <form role="form" method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo e(csrf_field()); ?>

                 <div class="form-row">
                    
                    <div class="form-group col-md-6<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <label for="inputName"><?php echo e(trans('user.name')); ?></label>
                        <input id="name" type="text" class="form-control" name="name" placeholder="Name" value="<?php echo e(old('name')); ?>" required>
                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email"><?php echo e(trans('user.email')); ?></label>
                        <input id="email" type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password"><?php echo e(trans('auth.password')); ?></label>
                        <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="password-confirm"><?php echo e(trans('auth.password_confirmation')); ?></label>
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Register</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kutumbh\resources\views/auth/register.blade.php ENDPATH**/ ?>