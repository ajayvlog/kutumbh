<?php

return [
    'birthday'    => 'Birthday',
    'upcoming'    => 'Upcoming birthdays',
    'no_upcoming' => 'No upcoming birthdays in the next :days days.',
    'remaining'   => ':count days',
    'age_years'   => ':age years',
    'days'        => 'days',
];
