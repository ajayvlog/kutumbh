@extends('admin.layouts.adminapp')

@section('title', 'Admin Dashboard')

@section('content')
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h3 class="mt-4">Dashboard</h3>
            </div>
        </main>
    </div>
@endsection